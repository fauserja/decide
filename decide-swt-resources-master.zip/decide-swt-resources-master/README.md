# DECIDE Semantic Web Technology Resources

This project contains publicly accessible semantic web technology based resources (RDF, SPARQL etc.) relevant for the DECIDE prototype.
