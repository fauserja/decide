PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# For "Task" and "Sub-Process" add a activityPerformedByActor property to an actor based on being inside of a "Lane" or "Pool".
INSERT {
    GRAPH ?bpmnModel {
        ?bpmnActivity :activityPerformedByActor ?actor .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        ?bpmnModel rdf:type mm:m_Business_process_diagram_BPMN_2_0 .
    }
    GRAPH ?bpmnModel {
        # Get all Task and Sub-Process resources.
        {
          ?bpmnActivity rdf:type mm:o_Task .
        } UNION {
          ?bpmnActivity rdf:type mm:o_Sub-Process .
        }
        # Get the actor they are inside.
        ?bpmnActivity mm:r_Is_inside ?actor .
        {
            ?actor rdf:type mm:o_Lane .
        } UNION {
            ?actor rdf:type mm:o_Pool .
        }
        # In BPMN the ?bpmnActivity can be both inside a Pool and a Lane or just a Pool.
        # This removes any bindings towards a Pool for bpmnActivity that is already inside a Lane.
        MINUS {
            ?actor rdf:type mm:o_Pool .
            ?bpmnActivity mm:r_Is_inside ?lane .
            ?lane rdf:type mm:o_Lane .
        }
    }
}
