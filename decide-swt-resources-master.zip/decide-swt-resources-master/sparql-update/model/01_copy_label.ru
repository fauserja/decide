PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# The names of modelling objects are stored through rdfs:label, so the value is also copied to :hasName.
# This is not handled through owl:sameAs as that would make every rdfs:label be considered for :hasName.
INSERT {
    GRAPH ?g {
        ?x :hasName ?label .
    }
} WHERE {
    GRAPH ?g {
        ?x rdfs:label ?label .
    }
}
