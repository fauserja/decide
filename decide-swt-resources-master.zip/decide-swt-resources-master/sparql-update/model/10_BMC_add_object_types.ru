PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# Add a specific type to "Building block" and "Element" based on the value of their "Type" attribute.
# Uses IF functions to determine the correct type.
INSERT {
    GRAPH ?bmcModel {
        ?elem rdf:type ?type .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        ?bmcModel rdf:type mm:m_Business_model_canvas .
    }
    GRAPH ?bmcModel {
        {
            ?elem rdf:type mm:o_Building_block .
            ?elem mm:a_Type ?subtype .
        } UNION {
            ?elem rdf:type mm:o_Element .
            ?elem mm:r_Is_inside ?bb .
            ?bb mm:a_Type ?subtype .
        }
        BIND (IF (?subtype = "Channels", :Channel,
            IF (?subtype = "Cost Structure", :CostStructure,
            IF (?subtype = "Customer Relationships", :CustomerRelationship,
            IF (?subtype = "Customer Segments", :CustomerSegment,
            IF (?subtype = "Key Activities", :KeyActivity,
            IF (?subtype = "Key Partners", :KeyPartner, # Note: This is necessary for a later distinction in 91_objects_in_models.ru.
            IF (?subtype = "Key Resources", :KeyResource,
            IF (?subtype = "Revenue Streams", :RevenueStream,
            IF (?subtype = "Value Propositions", :ValueProposition,
            :UnknownType
        ))))))))) as ?type) .
        FILTER (?type != :UnknownType) .
    }
} ;

# Also add the rdf:type :Actor to every :KeyPartner.
INSERT {
    GRAPH ?bmcModel {
        ?elem rdf:type :Actor .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        ?bmcModel rdf:type mm:m_Business_model_canvas .
    }
    GRAPH ?bmcModel {
        ?elem rdf:type :KeyPartner .
    }
} ;
