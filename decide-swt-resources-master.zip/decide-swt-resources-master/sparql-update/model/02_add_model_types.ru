PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# Add :BusinessModel type to "Business model canvas" and "e3-Value model" instances.
INSERT {
    GRAPH ?graphmetadata {
        ?model rdf:type :BusinessModel .
    }
} WHERE {
    GRAPH ?graphmetadata {
        {
            ?model rdf:type mm:m_Business_model_canvas .
        } UNION {
            ?model rdf:type mm:m_e3-Value_Model .
        }
    }
} ;

# Add :Process and :ValueProposition types to "Business process diagram (BPMN 2.0)" instances.
INSERT {
    GRAPH ?graphmetadata {
        ?model rdf:type :Process .
        ?model rdf:type :ValueProposition .
    }
} WHERE {
    GRAPH ?graphmetadata {
        ?model rdf:type mm:m_Business_process_diagram_BPMN_2_0 .
    }
}
