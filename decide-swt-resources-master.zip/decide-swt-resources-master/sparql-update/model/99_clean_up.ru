PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# At the end clean up anything that is unwanted.
# For example:
# * Delete attribute values (DatatypeProperty) that are only relevant in the Modelling Toolkit, like maybe :a_Fontcolor.
# * Delete the assignment to a :KeyPartner type that was added in `10_BMC_add_object_types.ru` and necessary for `91_objects_in_models.ru`.
DELETE {

} WHERE {

}
