PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# Add a specific type to instances of classes from BPMN models.
# These are straight forward.
# The assigned type is handled by binding it.
INSERT {
    GRAPH ?g {
        ?elem rdf:type ?type .
    }
} WHERE {
    GRAPH ?g {
        {
          ?elem rdf:type mm:o_actor .
          BIND (:Actor as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Actor_DSIR .
          BIND (:Actor as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Process .
          BIND (:Process as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Role .
          BIND (:Role as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Performer .
          BIND (:Actor as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Resource .
          BIND (:Resource as ?type) .
        }
    }
}
