PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# This adds the explicit "has..." properties between a :BusinessModel model and its instances.
# It assumes that the cebm types have already been assigned to the model and to the instances.
INSERT {
    GRAPH ?graphmetadata {
        ?model ?p ?o .
    }
} WHERE {
    GRAPH ?graphmetadata {
        ?model rdf:type :BusinessModel .
    }
    GRAPH ?model {
        {
          ?o rdf:type :Channel .
          BIND (:hasChannel as ?p) .
        } UNION {
          ?o rdf:type :CostStructure .
          BIND (:hasCostStructure as ?p) .
        } UNION {
          ?o rdf:type :CustomerRelationship .
          BIND (:hasCustomerRelationship as ?p) .
        } UNION {
          ?o rdf:type :CustomerSegment .
          BIND (:hasCustomerSegment as ?p) .
        } UNION {
          ?o rdf:type :KeyActivity .
          BIND (:hasKeyActivity as ?p) .
        } UNION {
          ?o rdf:type :KeyPartner .
          BIND (:hasKeyPartner as ?p) .
        } UNION {
          ?o rdf:type :KeyResource .
          BIND (:hasKeyResource as ?p) .
        } UNION {
          ?o rdf:type :MarketSegment .
          BIND (:hasMarketSegment as ?p) .
        } UNION {
          ?o rdf:type :PerformanceIndicator .
          BIND (:hasPerformanceIndicator as ?p) .
        } UNION {
          ?o rdf:type :RevenueStream .
          BIND (:hasRevenueStream as ?p) .
        } UNION {
          ?o rdf:type :ValueProposition .
          BIND (:hasValueProposition as ?p) .
        }
    }
} ;

# This adds the explicit "has..." properties between a :Process model and its instances.
# It assumes that the cebm types have already been assigned to the model and to the instances.
INSERT {
    GRAPH ?graphmetadata {
        ?model :processHasActivity ?o .
    }
} WHERE {
    GRAPH ?graphmetadata {
        ?model rdf:type :Process .
    }
    GRAPH ?model {
        ?o rdf:type :BPMNActivity .
    }
}
