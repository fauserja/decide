PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# Add explicit :hasValueExchange from a :ValueInterface to a :ValueExchange.
# It assumes that the cebm types have already been assigned to the model and to the instances.
INSERT {
    GRAPH ?e3vModel {
        ?valueInterface :hasValueExchange ?valueExchange .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        # This filters for instances in e3-Value models.
        # To also consider other models use a UNION or use the generic adoxx_mm:m_Model.
        # Or just remove this entire graph pattern if it doesn't matter where things are.
        ?e3vModel rdf:type mm:m_e3-Value_Model .
    }
    GRAPH ?e3vModel {
        ?valueExchange rdf:type :ValueExchange .
        ?valueExchange adoxx_mm:from ?valueInterface .
        ?valueInterface rdf:type :ValueInterface .
    }
} ;

# Add explicit :hasValueInterface from an :Actor to a :ValueInterface.
# It assumes that the cebm types have already been assigned to the model and to the instances.
INSERT {
    GRAPH ?e3vModel {
        ?actor :hasValueInterface ?valueInterface .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        # This filters for instances in e3-Value models.
        # To also consider other models use a UNION or use the generic adoxx_mm:m_Model.
        # Or just remove this entire graph pattern if it doesn't matter where things are.
        ?e3vModel rdf:type mm:m_e3-Value_Model .
    }
    GRAPH ?e3vModel {
        ?valueInterface rdf:type :ValueInterface .
        ?valueInterface mm:r_Is_inside ?actor .
        ?actor rdf:type :Actor .
    }
} ;

# Add explicit :isInMarketSegment from an :Actor to a :MarketSegment.
# It assumes that the cebm types have already been assigned to the model and to the instances.
INSERT {
    GRAPH ?e3vModel {
        ?actor :isInMarketSegment ?marketSegment .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        # This filters for instances in e3-Value models.
        # To also consider other models use a UNION or use the generic adoxx_mm:m_Model.
        # Or just remove this entire graph pattern if it doesn't matter where things are.
        ?e3vModel rdf:type mm:m_e3-Value_Model .
    }
    GRAPH ?e3vModel {
        ?actor rdf:type :Actor .
        ?actor mm:r_Is_inside ?marketSegment .
        ?marketSegment rdf:type :MarketSegment .
    }
}
