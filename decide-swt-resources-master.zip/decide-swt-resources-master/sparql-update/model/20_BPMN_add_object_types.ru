PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# Add a specific type to instances of classes from BPMN models.
# These are straight forward.
# The assigned type is handled by binding it.
INSERT {
    GRAPH ?bpmnModel {
        ?elem rdf:type ?type .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        ?bpmnModel rdf:type mm:m_Business_process_diagram_BPMN_2_0 .
    }
    GRAPH ?bpmnModel {
        {
          ?elem rdf:type mm:o_Data_Object .
          BIND (:Resource as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Lane .
          BIND (:Actor as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Performance_indicator .
          BIND (:PerformanceIndicator as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Pool .
          BIND (:Actor as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Pool_collapsed .
          BIND (:Actor as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Sub-Process .
          BIND (:BPMNActivity as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Sub-Process .
          BIND (:Process as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Task .
          BIND (:BPMNActivity as ?type) .
        }
    }
}
