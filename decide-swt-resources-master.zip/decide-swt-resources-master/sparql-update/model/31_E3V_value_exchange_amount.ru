PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# For a "value exchange" relation add the attribute value of "Display value" as :hasAmount.
INSERT {
    GRAPH ?e3vModel {
        ?valueExchange :hasAmount ?value .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        # This filters for instances in e3-Value models.
        # To also consider other models use a UNION or use the generic adoxx_mm:m_Model.
        # Or just remove this entire graph pattern if it doesn't matter where things are.
        ?e3vModel rdf:type mm:m_e3-Value_Model .
    }
    GRAPH ?e3vModel {
        ?valueExchange rdf:type mm:r_value_exchange .
        OPTIONAL { ?valueExchange mm:a_Display_value ?value . }
    }
}
