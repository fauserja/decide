PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# Add a specific type to instances of classes from e3-Value models.
# These are straight forward.
# The assigned type is handled by binding it.
INSERT {
    GRAPH ?e3vModel {
        ?elem rdf:type ?type .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        ?e3vModel rdf:type mm:m_e3-Value_Model .
    }
    GRAPH ?e3vModel {
        {
          ?elem rdf:type mm:o_Actor .
          BIND (:Actor as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Market_Segment .
          BIND (:MarketSegment as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Value_Interface .
          BIND (:ValueInterface as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Value_Interface .
          BIND (:RevenueStream as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Value_Object .
          BIND (:Resource as ?type) .
        } UNION {
          ?elem rdf:type mm:o_Value_Object .
          BIND (:ValueObject as ?type) .
        } UNION {
          ?elem rdf:type mm:r_value_exchange .
          BIND (:ValueExchange as ?type) .
        }
    }
}
