PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# For a "Performance indicator" add the attribute values of "Unit" and "Manual data input" when they exist.
INSERT {
    GRAPH ?bpmnModel {
        ?performanceIndicator :performanceUnit ?unit .
        ?performanceIndicator :performanceValue ?value .
    }
} WHERE {
    GRAPH adoxx_mm:graphmetadata {
        # This filters for instances in BPMN models.
        # To also consider other models use a UNION or use the generic adoxx_mm:m_Model.
        # Or just remove this entire graph pattern if it doesn't matter where things are.
        ?bpmnModel rdf:type mm:m_Business_process_diagram_BPMN_2_0 .
    }
    GRAPH ?bpmnModel {
        ?performanceIndicator rdf:type mm:o_Performance_indicator .
        OPTIONAL { ?performanceIndicator mm:a_Unit ?unit . }
        OPTIONAL { ?performanceIndicator mm:a_Manual_data_input ?value . }
    }
}
