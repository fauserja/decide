PREFIX :         <http://example.org/cebm#>
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>

# By setting mm:a_Description to the same as :hasDescription we should be able to avoid duplicate values.
INSERT DATA {
  GRAPH mm:decide_metamodel {
    mm:a_Description owl:equivalentProperty :hasDescription .
  }
}
