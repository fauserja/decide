from dash import Dash, html, dcc
import plotly.express as px
import pandas as pd
import requests

def fetch_count_from_graphdb():
    query = """
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:  <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

SELECT
  (COUNT(DISTINCT ?class) AS ?classCount)
  (COUNT(DISTINCT ?property) AS ?propertyCount)
WHERE {
  {
    ?class a rdfs:Class .
  }
  UNION
  {
    ?property a rdf:Property .
  }
}
    """
    response = requests.post(
        'http://localhost:7200/repositories/cebm_ontology',
        data={'query': query},
        headers={'Accept': 'application/sparql-results+json'}
    )
    if response.status_code == 200:
        result = response.json()
        bindings = result['results']['bindings'][0]
        class_count = int(bindings['classCount']['value'])
        property_count = int(bindings['propertyCount']['value'])
        return class_count, property_count
    else:
        return None, None

class_count, property_count = fetch_count_from_graphdb()
df = pd.DataFrame({'Label': ['Classes', 'Properties'], 'Value': [class_count, property_count]})

app = Dash()

app.layout = html.Div([
    html.H1(children='GraphDB Class & Property Count Dashboard', style={'textAlign':'center'}),
    html.Div(children=f"Classes: {class_count}, Properties: {property_count}", style={'textAlign': 'center', 'fontSize': 20}),
    dcc.Graph(id='graph-content', figure=px.pie(df, names='Label', values='Value', title='Classes vs Properties'))
])

if __name__ == '__main__':
    app.run(debug=True)
