import threading
from dash import Dash, html, dcc, callback, Output, Input
import plotly.express as px
import pandas as pd
import time

df = pd.read_csv('https://raw.githubusercontent.com/plotly/datasets/master/gapminder_unfiltered.csv')

#print(df.to_dict('records'))

app = Dash()


# Requires Dash 2.17.0 or later
app.layout = [
    html.H1(children='Title of Dash App', style={'textAlign':'center'}),
    dcc.Dropdown(df.country.unique(), 'Canada', id='dropdown-selection'),
    dcc.Graph(id='graph-content')
]
#app.layout.append(dcc.Graph(id=f'othergraph-hugo', figure=px.line(df[df.country=='Australia'], x='year', y='pop')))
#app.layout.append(px.line(df[df.country=='Australia'], x='year', y='pop')) # This doesn't work

@callback(
    Output('graph-content', 'figure'),
    Input('dropdown-selection', 'value')
)
def update_graph(value):
    dff = df[df.country==value]
    return px.line(dff, x='year', y='pop')

@callback(
    Input('dropdown-selection', 'value')
)
def add_graph(value):
    dff = df[df.country==value]
    print('Hugo')
    fig = px.line(dff, x='year', y='pop')
    app.layout.append(dcc.Graph(id=f'othergraph-{value}', figure=fig))

#@callback(
#    Input(component_id="url", component_property="pathname"),
#)
#def display_page(pathname):
#    print(pathname) 

print('Reloaded')

def somefun():
    for i in range(20):
        print("Hello")
        app.layout.append(dcc.Graph(id=f'othergraph-{i}', figure=px.line(df[df.country=='Burundi'], x='year', y='pop')))
        time.sleep(1)
    print("Thread Dead")

if __name__ == '__main__':
    mythread = threading.Thread(target=somefun)
    #mythread.start()

    app.run(debug=True)
    #app.layout.append(dcc.Graph(id='othergraph', figure=px.line(df[df.country=='Burundi'], x='year', y='pop')))
