from dash import Dash, dash_table, dcc, html, Input, Output, callback
import pandas as pd

import time
print(f'Loading code at {time.strftime('%H:%M:%S')}')

df = pd.read_csv('https://raw.githubusercontent.com/plotly/datasets/master/gapminder2007.csv')

#df = pd.DataFrame([{'country': {'label': 'Hello', 'value': '3'}, 'pop': 0, 'continent': 'Europe', 'lifeExp': 0, 'gdpPercap': 0}])
#print(df)

app = Dash()

app.layout = html.Div([
    dash_table.DataTable(
        id = 'datatable-interactivity',
        columns = [
            {'name': i, 'id': i, 'deletable': True, 'selectable': True} for i in df.columns
        ],
        data = df.to_dict('records'), # type: ignore
        editable = True,
        filter_action = 'native',
        sort_action = 'native',
        sort_mode = 'multi',
        column_selectable = 'single',
        row_selectable = 'multi',
        row_deletable = True,
        selected_columns = [],
        selected_rows = [],
        page_action = 'native',
        page_current= 0,
        page_size= 10,
    ),
    html.Div(id = 'datatable-interactivity-container')
])

@callback(
    Output('datatable-interactivity', 'style_data_conditional'),
    Input('datatable-interactivity', 'selected_columns')
)
def update_styles(selected_columns):
    return [{
        'if': { 'column_id': i },
        'background_color': '#D2F3FF'
    } for i in selected_columns]

@callback(
    Output('datatable-interactivity-container', 'children'),
    Input('datatable-interactivity', 'derived_virtual_data'),
    Input('datatable-interactivity', 'derived_virtual_selected_rows'))
def update_graphs(rows, derived_virtual_selected_rows):
    # When the table is first rendered, `derived_virtual_data` and
    # `derived_virtual_selected_rows` will be `None`. This is due to an
    # idiosyncrasy in Dash (unsupplied properties are always None and Dash
    # calls the dependent callbacks when the component is first rendered).
    # So, if `rows` is `None`, then the component was just rendered
    # and its value will be the same as the component's dataframe.
    # Instead of setting `None` in here, you could also set
    # `derived_virtual_data = df.to_rows('dict')` when you initialize
    # the component.
    if derived_virtual_selected_rows is None:
        derived_virtual_selected_rows = []

    dff = df if rows is None else pd.DataFrame(rows)

    colors = ['#7FDBFF' if i in derived_virtual_selected_rows else '#0074D9'
              for i in range(len(dff))]

    return [
        dcc.Graph(
            id = column,
            figure = {
                'data': [
                    {
                        'x': dff['country'],
                        'y': dff[column],
                        'type': 'bar',
                        'marker': {'color': colors},
                    }
                ],
                'layout': {
                    'xaxis': {'automargin': True},
                    'yaxis': {
                        'automargin': True,
                        'title': {'text': column}
                    },
                    'height': 250,
                    'margin': {'t': 10, 'l': 10, 'r': 10},
                },
            },
        )
        # check if column exists - user may have deleted it
        # If `column.deletable = False`, then you don't
        # need to do this check.
        for column in ['pop', 'lifeExp', 'gdpPercap'] if column in dff
    ]





#region --- Main -------------------------------------------------------------
# Code to execute when this script is executed as the "__main__" script.
#-----------------------------------------------------------------------------

if __name__ == '__main__':
    # Get the port from the configuraiton or use default port 8050.
    PORT = 8050
    # Try to open the dashboard page in the webbrowser.
    try:
        import os
        # Checkin this environment variables makes the browser window open only ONCE.
        # Otherwise when changing the code in debug mode it would open the page again and again and again.
        if not os.environ.get('WERKZEUG_RUN_MAIN'):
            from threading import Timer
            import webbrowser
            # Opening on a timer to let the app start first.
            Timer(1, webbrowser.open, [f'http://localhost:{PORT}/']).start()
    except Exception:
        pass
    # Start the Dash app.
    app.run(debug = True, host = '0.0.0.0', port = PORT)

#endregion -------------------------------------------------------------------
