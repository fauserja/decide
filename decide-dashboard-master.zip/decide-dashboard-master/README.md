# DECIDE Dashboard

This project contains the artifacts required to realize the dashboard for the DECIDE project.

The dashboard is realized in [Python](https://www.python.org/) using the [Dash](https://dash.plotly.com/) module.



## Use locally

Note: executing commands through the CLI should happen from inside the project's directory unless stated otherwise.

1. [Install Python](https://www.python.org/downloads/). This has so far been tested with version 3.12.
2. Create a virtual environment and activate it (recommended):
    1. Execute the command `python -m venv .venv --prompt decide-dashboard`.
      To use a specific python version specify an absolute to the `python` executable,
      e.g. `c:\programming\Python3-12\python.exe -m venv .venv --prompt decide-dashboard`.
    2. Activate the virtual environment by executing one of the activation scripts from the `.venv/Scripts/` directory,
      e.g. `.venv/Scripts/activate.bat` or `.venv/Scripts/Activate.ps1`.
      Make sure to always activate the environment like this when using the Dashboard.
3. Install the requirements by executing `pip install -r .\requirements.txt` (newest versions) or
  `pip install -r .\requirements-freeze.txt` (versions used for testing / development).
4. Update the configuration in the `decide_dashboard.properties` file.
5. Start the dashboard by executing `python './dashboard/decide_dashboard.py'`
  This should automatically open a browser window to the dashboard.
  If not then it can be accessed via the URL http://localhost:7000/

> There are also Visual Studio Code tasks defined to start the dashboard locally using Python from `./.venv/Scripts/python.exe`.

Using the dashboard requires the Olive MSC from the [DECIDE Data Platform](https://code.omilab.org/research-projects/decide/decide-data-platform) to be deployed and running.

One of the available layouts for the network graphs is cose-bilkent:  
U. Dogrusoz, E. Giral, A. Cetintas, A. Civril, and E. Demir, "A Layout Algorithm For Undirected Compound Graphs", Information Sciences, 179, pp. 980-994, 2009.

> Parts of the dashboard references things from the ontology that do not exist in the ontology,
> for example explicit IRIs for the 7R strategies (http://example.org/cebm#Reduce,
> http://example.org/cebm#Reuse, http://example.org/cebm#Repair etc.) or the hasCEBMType property.
> These are however necessary for the dashboard to query data.
> See examples for details.



## Access rules

The "rules" of what user group can see which results are very simple and are based on RDF data stored:
The `cebmauth:auth_rules` graph specifies the user groups and what resources they can access by specifying them via `cebmauth:allowed_resource_iri` properties.
Inheritance of allowed IRIs is possible between user groups through the `cebmauth:inherits_from` property.

The SPARQL queries executed by the dashboard include filters to remove results that contain IRI resources that are not in the `cebmauth:allowed_resource_iri` of a user group.



## Examples

Some example data can be found in the `examples/` directory.

To use the basic examples it is necessary to at least:
* Import the ontology `cebm_ontology_02.trig` into the data platform repository (should be part of the data platform project).
* Import the meta-model description RDF `decide_01_mm.trig` into the data platform repository (should be part of the data platform project).
* Import `examples/user-example-data-basic.trig` into the data platform repository.
  This sets up the basic "Everyone" user group that other user groups inherit from.
  This group is allowed to access the resource IRIs from the ontology.
* Import `examples/icq-example-data.trig` into the data platform repository.
  Not all data can be created / linked properly in the DECIDE Modelling Toolkit.
* Upload the models from `examples/agnostic-model-export-example` and `examples/car-manufacturer-model-export-example` into the data platform.
  Import either the provided `.trig` files into the data platform or
  import the `.adl` files in the Modelling Toolkit and upload the content from there.



## Notes

The custom stylesheet is located in the `stylesheets/decide-dashboard/` folder and is built using [SASS](https://sass-lang.com/) (tested with dart-sass v1.90.0).
There are also a Visual Studio Code task defined to build the stylesheets.

SPARQL queries and functions that retrieve RDF data now also try to assign labels to IRI resources (represented through RdfIriResource objects). These are then used in the UI when possible. Note however that the client side of the dashboard looses any datatype that goes beyond JSON, so the IRIs must also be put somewhere in the UI (like the tooltips of graphs) if they are to be used for further queries / processing!

Alternative for managing what data user groups can access (that might be faster than the current one): Rework the RDF Export result to get rid of using graphs (context) for models and instead put the triples into graphs (context) based on what user group can access them. This could however require duplicating some data (especially the ontology data) and for data that is being queried not requiring to cross the boundaries of a graph (i.e. results fully contained inside ONE graph) as otherwise the SPARQL patterns would have to use many different graph patterns, since we might not necessarily know in what specific graph some things end up beforehand.

When the necessary logic to "get all allowed resources" becomes more complex beyond what can be achieved now with the (relatively simple) property path consider adding a subquery that binds a variable to all allowed resources and then returns a GROUP_CONCAT (string) of those. Then the outer query could use filter to check if the resource IRI (as a string literal) is contained in the result. Something like:
```sparql
SELECT ?Business_model
WHERE {
    # Get all resources that a user group is allowed to access.
    { SELECT (GROUP_CONCAT(?allowed_resource) AS ?allowed_resources)
        WHERE {
            <http://example.org/cebm/auth/#Everybody> (owl:sameAs|cebmauth:inherits_from+)/cebmauth:allowed_resource ?allowed_resource .
        }
    }

    ?Business_model rdf:type cebm:BusinessModel .
    FILTER (CONTAINS(?allowed_resources, STR(?Business_model)))
}
```

Maybe [federated queries](https://www.w3.org/TR/sparql11-federated-query/) (or [specific for GraphDB](https://graphdb.ontotext.com/documentation/11.0/sparql-federation.html))could help in splitting some of the data, like storing the access rights in a different repository?
