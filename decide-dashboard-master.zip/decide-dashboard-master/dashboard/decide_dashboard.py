# Python internal modules.
import configparser
import sys
from typing import Any, Hashable, Mapping
from uuid import uuid1

# 3rd party modules.
from dash import callback, clientside_callback, ClientsideFunction, ctx, Dash, dash_table, dcc, exceptions, html, Input, no_update, NoUpdate, Output, State
from dash.development.base_component import Component
import dash_bootstrap_components as dbc
import dash_cytoscape as cyto
import numpy as npy
import pandas as pd
import plotly.express as px

# Other code from this project.
from dashboard_utils import RdfIriResource, SparqlResultsToWideDict, SparqlResultsToDataFrame, SparqlResultsToWideDataFrame, SparqlQueryOlive, dataframe_labels_for_values, get_columns_definition

# Some imports are conditional, especially in the __main__ portion of the code (only importing what is needed when running as main).
# All others are imported at the start of the file.



# Note: Type-checking is disabled for certain lines (# type: ignore).
# In those cases we expect it either to work or otherwise to exit with an exception, since we can't handle it.

# On data types: any data that gets moved outside of the Python environment and into the browser,
# like data moved through callbacks, is coerced into JSON data types.
# Custom data types are therefore lost, but can still be useful for a little while before the data is moved between the two.
# Also note: https://dash.plotly.com/sharing-data-between-callbacks#why-global-variables-will-break-your-app
# This is the reason why IRIs (URLs) are always in some part of a component in Dash / Plotly.

# On DataTable and active_cell: when using 'data' as the input, then use 'row_id'. When using 'derived_virtual_data', then use 'row'.



#region --- Process input arguments ------------------------------------------
# Process some input parameters and simple setup to make debugging easier.
# All the relevant configuration is handled through the decide_dashboard.properties file.
#-----------------------------------------------------------------------------

debug = False
started_through_debugger = False
for arg in sys.argv:
    match(arg):
        case '--debug':
            debug = True
        case '--debugger':
            started_through_debugger = True
# When running in debug mode the app can reload, so we print the time to indicate that a reload has happened.
if debug:
    import time
    print(f'Loading code at {time.strftime('%H:%M:%S')}')

#endregion -------------------------------------------------------------------



#region --- Load configuration -----------------------------------------------
# Load the configuration from a file and other configuration variables.
#-----------------------------------------------------------------------------

config = configparser.ConfigParser()
config.read('decide_dashboard.properties')
config_dataplatform:Mapping = config['DECIDE.dataplatform']
config_dashboard:Mapping = config['DECIDE.dashboard']
config_rdf:Mapping = config['DECIDE.rdf']

# Helper constants that are used in several places and / or have a default value.
DASHBOARD_URL_PATH = config_dashboard.get('dashboardPath', '/')
STARTING_NETWORK_GRAPH_LAYOUT = config_dashboard.get('networkGraphLayout', 'concentric')
DERIVE_MISSING_LABELS = config_rdf.getboolean('deriveMissingLabels', True)

# Load additional layouts to be available in cytoscape when necessary.
# Needed for example for the 'cola' layout, but not for:
# ['random', 'preset', 'circle', 'concentric', 'grid', 'breadthfirst', 'cose'].
cyto.load_extra_layouts()

# Layout configurations for the available layout algorithms.
PREDEFINED_LAYOUT_CONFIGURATIONS = {
    'circle': {'name': 'circle', 'fit': True, 'padding': 100, 'animate': False},
    'concentric': {'name': 'concentric', 'fit': True, 'padding': 100, 'animate': False, 'minNodeSpacing': 75},
    'grid': {'name': 'grid', 'fit': True, 'padding': 100, 'animate': False},
    'breadthfirst': {'name': 'breadthfirst', 'fit': True, 'padding': 100, 'animate': False, 'spacingFactor': 2},
    'cose': {'name': 'cose', 'fit': True, 'padding': 100, 'animate': False, 'randomize': True},
    'cose-bilkent': {'name': 'cose-bilkent', 'fit': True, 'padding': 100, 'animate': False, 'randomize': True, 'idealEdgeLength': 200, 'tilingPaddingVertical': 50, 'tilingPaddingHorizontal': 50},
    'cola': {'name': 'cola', 'fit': True, 'padding': 100, 'animate': False, 'nodeSpacing': 50},
    'spread': {'name': 'spread', 'fit': True, 'padding': 100, 'animate': False, 'minDist': 50},
    'dagre': {'name': 'dagre', 'fit': True, 'padding': 100, 'animate': False, 'nodeSep': 50, 'edgeSep': 20},
    'klay': {'name': 'klay', 'fit': True, 'padding': 100, 'animate': False}
}

# A stylesheet for cytoscape to represent RDF-like data.
# Note that the priority here is NOT based on the selector but on the order with later ones overwriting previous styles!
CYTOSCAPE_RDF_STYLESHEET = [
    {   # Default style for everything.
        'selector': '*',
        'style': {
            'label': 'data(label)',
            'text-wrap': 'ellipsis',
            'text-outline-color': '#dddddd',
            'text-outline-opacity': 1,
            'text-outline-width': 2
        }
    }, { # Default style for nodes.
        'selector': 'node',
        'style': {
            'width': 50,
            'height': 50,
            'text-max-width': 100
        }
    }, { # Default style for selected nodes.
        'selector': 'node:selected',
        'style': {
            'overlay-color': 'blue',
            'overlay-padding': 2,
            'overlay-opacity': 0.5,
            'overlay-shape': 'round-rectangle'
        }
    }, { # Nodes representing an RDF resources.
        'selector': 'node.resource',
        'style': {
            'background-color': '#339999',
            #'border-width': 1, # cola layout doesn't seem to like border-width and default seems to be 0.
            #'border-style': 'solid',
            #'border-color': '#225555',
            #'outline-width': 1, # cola layout is fine with outline though...
            #'outline-style': 'solid',
            #'outline-color': '#225555'
        }
    }, { # Nodes representing a literal.
        'selector': 'node.literal',
        'style': {
            'shape': 'round-triangle',
            'background-color': '#5566bb',
            #'border-width': 1, # cola layout doesn't seem to like border-width and default seems to be 0.
            #'border-style': 'solid',
            #'border-color': '#113399',
            #'outline-width': 1, # cola layout is fine with outline though...
            #'outline-style': 'solid',
            #'outline-color': '#113399'
        }
    }, { # Default style for edges.
        'selector': 'edge',
        'style': {
            'curve-style': 'straight',
            'target-arrow-shape': 'triangle-backcurve',
            'arrow-scale': 1.5,
            'text-rotation': 'autorotate'
        }
    }, { # Default style for selected edges.
        'selector': 'edge:selected',
        'style': {
            'overlay-color': 'blue',
            'overlay-padding': 2,
            'overlay-opacity': 0.5,
            'overlay-shape': 'round-rectangle'
        }
    }, { # Edges targeting an RDF resources.
        'selector': 'edge.resource-target',
        'style': {
            'line-color': '#225555',
            'target-arrow-color': '#225555'
        }
    }, { # Edges targeting a literal.
        'selector': 'edge.literal-target',
        'style': {
            'line-color': '#113399',
            'target-arrow-color': '#113399'
        }
    }
]

# A stylesheet for cytoscape with specific styles for the DECIDE dashboard.
# Note that the priority here is NOT based on the selector but on the order with later ones overwriting previous styles!
CYTOSCAPE_CEBM_STYLESHEET = [
    {
        'selector': 'node.business_model',
        'style': {
            'background-color': '#a52a2a',
            #'border-width': 1, # cola layout doesn't seem to like border-width and default seems to be 0.
            #'border-style': 'solid',
            #'border-color': '#1e90ff',
            #'outline-width': 1, # cola layout is fine with outline though...
            #'outline-style': 'solid',
            #'outline-color': '#b22222'
        }
    }
]

#endregion -------------------------------------------------------------------



#region --- Init helpers -----------------------------------------------------
# Initialize helper objects.
# These make working with the Olive MSC and SPARQL easier.
#-----------------------------------------------------------------------------

# Helper object to execute SPARQL queries through the Olive MSC.
sq = SparqlQueryOlive(config_dataplatform.get('oliveMscEndpoint'), # type: ignore
        config_dataplatform.get('oliveMicroserviceName'), # type: ignore
        config_dataplatform.get('oliveSparqlQueryOperation'), # type: ignore
        config_dataplatform.get('dataPlatformRepositoryId'), # type: ignore
        config_rdf.get('defaultSparqlPrefix')
    )

# IRIs of specific resources used throughout the app.
IRI_CEBM_PREFIX = 'http://example.org/cebm#'
IRI_UNKNOWN = RdfIriResource(f'{IRI_CEBM_PREFIX}Unknown')
IRI_NONE = RdfIriResource(f'{IRI_CEBM_PREFIX}None')
IRI_BUSINESS_MODEL = RdfIriResource(f'{IRI_CEBM_PREFIX}BusinessModel')
# Lists of IRIs of specific resources used throughout the app. The key is a "readable" name while the value is the actual IRI.
# Types of circular economy business models: Cycling, Dematerializing, Extending, Intensifying
IRIS_CEBM_TYPE = {name: RdfIriResource(f'{IRI_CEBM_PREFIX}{name}') for name in ['Cycling', 'Dematerializing', 'Extending', 'Intensifying']}
# 7R strategies: Reduce, Reuse, Repair, Refurbish, Remanufacture, Repurpose, Recycle
IRIS_STRATEGY = {name: RdfIriResource(f'{IRI_CEBM_PREFIX}{name}') for name in ['Reduce', 'Reuse', 'Repair', 'Refurbish', 'Remanufacture', 'Repurpose', 'Recycle']}
# Performance indicator dimensions: environmental, economic, social
IRIS_DIMENSION = {name: RdfIriResource(f'{IRI_CEBM_PREFIX}{name}') for name in ['Environmental', 'Economic', 'Social']}

# With the following queries use str.format() to insert the IRI of a resource as a positional argument
# and the user_group keyword argument to specify for what user group it is executed.
# These use VALUES so that the bound value itself is also returned as a binding in the result.
# Insert IRI into s to find p + o bindings.
# -> All triples for subject.
SPARQL_QUERY_S_PO = """SELECT ?Subject ?Property ?Object ?_label_Subject ?_label_Property ?_label_Object
    WHERE {{
        VALUES ?Subject {{ <{0}> }}
        ?Subject ?Property ?Object .

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property_iri ?Property . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }}) &&
            # Filter out x owl:sameAs x.
            ((?Property != owl:sameAs) || (?Subject != ?Object))
        )

        # Get optional labels for each of them.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
        OPTIONAL {{ ?Property rdfs:label ?_label_Property . }}
        OPTIONAL {{ ?Object rdfs:label ?_label_Object . }}
    }}
"""
# Insert IRI into p to find s + o bindings.
# -> All triples for object.
SPARQL_QUERY_P_SO = """SELECT ?Subject ?Property ?Object ?_label_Subject ?_label_Property ?_label_Object
    WHERE {{
        VALUES ?Property {{ <{0}> }}
        ?Subject ?Property ?Object .

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property ?Property . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }}) &&
            # Filter out x owl:sameAs x.
            ((?Property != owl:sameAs) || (?Subject != ?Object))
        )

        # Get optional labels for each of them after we have filtered out some of the bindings.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
        OPTIONAL {{ ?Property rdfs:label ?_label_Property . }}
        OPTIONAL {{ ?Object rdfs:label ?_label_Object . }}
    }}
"""
# Insert IRI into o to find s + p bindings.
# -> All triples for object.
SPARQL_QUERY_O_SP = """SELECT ?Subject ?Property ?Object ?_label_Subject ?_label_Property ?_label_Object
    WHERE {{
        VALUES ?Object {{ <{0}> }}
        ?Subject ?Property ?Object .

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property ?Property . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }}) &&
            # Filter out x owl:sameAs x.
            ((?Property != owl:sameAs) || (?Subject != ?Object))
        )

        # Get optional labels for each of them after we have filtered out some of the bindings.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
        OPTIONAL {{ ?Property rdfs:label ?_label_Property . }}
        OPTIONAL {{ ?Object rdfs:label ?_label_Object . }}
    }}
"""
# Insert first IRI into s and second IRI into o to find p bindings.
# -> All properties between specific subject and object.
SPARQL_QUERY_SO_P = """SELECT ?Subject ?Property ?Object ?_label_Subject ?_label_Property ?_label_Object
    WHERE {{
        VALUES ( ?Subject ?Object ) {{ ( <{0}> <{1}> ) }}
        ?Subject ?Property ?Object .

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property ?Property . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }})
        )

        # Get optional labels for each of them after we have filtered out some of the bindings.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
        OPTIONAL {{ ?Property rdfs:label ?_label_Property . }}
        OPTIONAL {{ ?Object rdfs:label ?_label_Object . }}
    }}
"""
# Insert IRI into s to find p + o bindings UNION insert IRI into o to find s + p bindings.
# -> All triples where resource is either the subject or the object.
SPARQL_QUERY_S_PO_U_O_SP = """SELECT ?Subject ?Property ?Object ?_label_Subject ?_label_Property ?_label_Object
    WHERE {{
        {{
            VALUES ?Subject {{ <{0}> }}
            ?Subject ?Property ?Object .
        }} UNION {{
            VALUES ?Object {{ <{0}> }}
            ?Subject ?Property ?Object .
        }}

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property ?Property . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }}) &&
            # Filter out x owl:sameAs x.
            ((?Property != owl:sameAs) || (?Subject != ?Object))
        )

        # Get optional labels for each of them after we have filtered out some of the bindings.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
        OPTIONAL {{ ?Property rdfs:label ?_label_Property . }}
        OPTIONAL {{ ?Object rdfs:label ?_label_Object . }}
    }}
"""
# Insert IRI into p to find s + o bindings UNION insert IRI into o to find s + p bindings.
# -> All triples where resource is either the property or the object.
SPARQL_QUERY_P_SO_U_P_SP = """SELECT ?Subject ?Property ?Object ?_label_Subject ?_label_Property ?_label_Object
    WHERE {{
        {{
            VALUES ?Property {{ <{0}> }}
            ?Subject ?Property ?Object .
        }} UNION {{
            VALUES ?Object {{ <{0}> }}
            ?Subject ?Property ?Object .
        }}

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property ?Property . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }}) &&
            # Filter out x owl:sameAs x.
            ((?Property != owl:sameAs) || (?Subject != ?Object))
        )

        # Get optional labels for each of them after we have filtered out some of the bindings.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
        OPTIONAL {{ ?Property rdfs:label ?_label_Property . }}
        OPTIONAL {{ ?Object rdfs:label ?_label_Object . }}
    }}
"""
# Insert IRI into o with p as rdf:type to find s bindings.
# -> All resources of a specific type.
SPARQL_QUERY_S_OF_RDF_TYPE = """SELECT ?Subject ?_label_Subject
    WHERE {{
        VALUES ?Object {{ <{0}> }}
        ?Subject rdf:type ?Object .

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property rdf:type . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }})
        )

        # Get optional label after we have filtered out some of the bindings.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
    }}
"""

# Helper function which gathers details for a specific IRI resource and returns the results in a tuple for DataTable.data, DataTable.columns and DataTable.tooltip_data.
def get_iri_resource_statements(res:str, user_group:str, query:str = SPARQL_QUERY_S_PO) -> tuple[list[dict[Hashable, Any]], list[dict], list[dict]]:
    details_bindings = sq.execute_query(query.format(res, user_group = user_group))
    details_df = SparqlResultsToDataFrame(DERIVE_MISSING_LABELS).transform(details_bindings)
    columns = get_columns_definition(details_df)
    tooltips = [
        {
            col: {'value': str(getattr(row, col))} for col in row._fields # type: ignore
        } for row in details_df.itertuples(False)
    ]
    # Change the values from IRIs to more readable labels when possible.
    details_df_labeled = dataframe_labels_for_values(details_df, '🌐 ')
    return details_df_labeled.to_dict('records'), columns, tooltips

# Function that creates a Cytoscape node for a value.
def create_cytoscape_node(val:Any, additional_classes:str | list[str] = '') -> dict[str, Any]:
    # Make val be an RdfIriResource when possible.
    val = RdfIriResource.cast_if_valid(val)
    is_iri = isinstance(val, RdfIriResource)
    node = {
        'group': 'nodes',
        'data': {
            'id': val if is_iri else uuid1().urn,
            'label': val.label if is_iri else str(val)
        },
        'classes': ('resource' if is_iri else 'literal') +
            ((' ' + (' '.join(additional_classes) if isinstance(additional_classes, list) else additional_classes)) if additional_classes else '')
    }
    # Also add an 'iri' attribute to the data when available.
    if is_iri:
        node['data']['iri'] = val
    return node

# Function that creates a a Cytoscape edge for a value between to existing nodes.
#TODO document that source and target must be Cytoscape nodes (for example as returned by create_cytoscape_node).
def create_cytoscape_edge(val:Any, source:dict, target:dict, additional_classes:str | list[str] = '') -> dict[str, Any]:
    # Make val be an RdfIriResource when possible.
    val = RdfIriResource.cast_if_valid(val)
    is_iri = isinstance(val, RdfIriResource)
    source_data:dict[str, Any] = source.get('data', {})
    target_data:dict[str, Any] = target.get('data', {})
    target_class = 'resource-target' if 'resource' in target.get('classes', '') else ('literal-target' if 'literal' in target.get('classes', '') else '')
    edge = {
        'group': 'edges',
        'data': {
            #'id': val if is_iri else uuid1().urn,
            'source': source['data']['id'],
            'target': target['data']['id'],
            'label': val.label if is_iri else str(val),
            'source_info': source_data.get('iri', source_data.get('label', '')),
            'target_info': target_data.get('iri', target_data.get('label', ''))
        },
        'classes': target_class +
            ((' ' + (' '.join(additional_classes) if isinstance(additional_classes, list) else additional_classes)) if additional_classes else '')
    }
    if is_iri:
        edge['data']['iri'] = val
    return edge

# Function that creates a list of Cytoscape nodes and edges from a 2D dictionary.
# See SparqlQueryOlive.sparql_bindings_to_2d_dict(...) for the excepted structure of the 2D dictionary.
def cytoscape_elements_from_2d_dict(subj_info:dict[str, dict[str, Any]]) -> list[dict]:
    known_nodes = []
    graph_elements = []
    for subj, subj_obj in subj_info.items():
        subj_node = create_cytoscape_node(subj)
        if subj_node['data']['id'] not in known_nodes:
            graph_elements.append(subj_node)
            known_nodes.append(subj_node['data']['id'])
        for prop, obj_val in subj_obj.items():
            # For easier code we either treat obj_val as a list or coerce it into one.
            for one_val in (obj_val if isinstance(obj_val, list) else [obj_val]):
                # Add the "target" node for a property if it doesn't already exist.
                obj_node = create_cytoscape_node(one_val)
                if obj_node['data']['id'] not in known_nodes:
                    graph_elements.append(obj_node)
                    known_nodes.append(obj_node['data']['id'])
                # Add the edge representing the property.
                graph_elements.append(create_cytoscape_edge(prop, subj_node, obj_node))
    return graph_elements

#endregion -------------------------------------------------------------------



#region --- Basic App structure ----------------------------------------------
# Create the Dash app object and set up a basic layout.
# The layout is one navigation bar followed by one main container for the
# rest of the app with sub-containers for each distinct part (ICQ).
#-----------------------------------------------------------------------------

# Navigation bar for the app.
app_navbar = dbc.NavbarSimple(
    # Contents dynamically added later.
    id = 'decide-dashboard-navbar',
    class_name = 'mb-3',
    brand = [
        html.Img(src = 'assets/icon_decide.png', className = 'me-1'),
        html.H1('DECIDE Dashboard', id = 'decide-dashboard-header')
    ],
    brand_href = '#',
    sticky = 'top', expand = 'lg'
)

# The main bootstrap container for the app where sub-containers are added later.
app_container = dbc.Container([
        dcc.Store(id = 'decide-dashboard-current-user-group', data = ''), # Stores the allowed user group for callbacks.
        html.Div([
                dbc.Row([
                        dbc.Col([
                                dbc.Label('User group selection:', html_for = 'decide-dashboard-user-group-selection'),
                                dcc.Loading(
                                    dcc.Dropdown(
                                        # Options and value are added via callback.
                                        id = 'decide-dashboard-user-group-selection',
                                        placeholder = 'Select a user group',
                                        clearable = False
                                    ),
                                    delay_show = 100,
                                    overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                                )
                            ]
                        )
                    ],
                    class_name = 'align-items-center gx-3 gy-1 mb-3'
                )
            ]
        )
    ],
    # The dash-bootstrap class only properly works when using the SPECIAL dash-bootstrap-4.5.3 bootstrap.css,
    # but that one seems rather outdated (especially since dbc.themes.BOOTSTRAP references 5.3.6) ...
    # We will have to make our own updated version of that.
    id = 'decide-dashboard-app',
    class_name = 'dash-bootstrap container-lg',
    fluid = True
)

# Now set up the app and its layout.
# The __name__ is used to load resources (CSS, JS etc.) from the `assets` folder.
app = Dash(
    __name__,
    external_stylesheets = [
        #{'href': dbc.themes.BOOTSTRAP, 'rel': 'stylesheet'}, # Instead the bootstrap style from the `assets/` directory is used.
        {'href': dbc.icons.BOOTSTRAP, 'rel': 'stylesheet'} # To allow Bootstrap icons.
    ],
    title = 'DECIDE Dashboard',
    update_title = 'DECIDE Dashboard*',
    url_base_pathname = DASHBOARD_URL_PATH
)
app.layout = html.Div([
        dcc.Location(id = 'url', refresh = False), # Used to load content when the page is (re-)loaded.
        app_navbar,
        app_container
    ],
)

# Callback to update the user group when the value in the dropdown changes.
clientside_callback(
    ClientsideFunction('clientside', 'changeUserGroup'),
    Output('decide-dashboard-current-user-group', 'data'),
    Input('decide-dashboard-user-group-selection', 'value')
)

# Details to set up the Informal Competency Questions containers as part of the app layout.
# The actual layout for each of those containers is configured later as they vary drastically.
ICQ_INFO = [{
        'question': 'Which circular business models exist in a region/country, and how can they be classified?',
        'usage': ['The first table shows a list of available circular economy business models with some of their details.', html.Br(),
            'Select an entry in the first table and select "Show Details" to show in the second table ("Details") where the entry is used as a Subject.', html.Br(),
            'The details in the second table are read like a sentence in the form of "[Subject] [Property] [Object]", for example "e3-Value_ICP hasGeographicContext Slovenia" or "e3-Value_ICP hasSector Farming".', html.Br(),
            'Select an entry in the second table and select one of "Subject", "Property" or "Object" to update the second table showing where the entry is used as a subject, property or object respectively.', html.Br(),
            'Use the filters below the table headers to quickly find specific entries in the tables.', html.Br(),
            'The 🌐 icon is placed at the beginning of complex entries, meaning that they can have additional properties assigned to them.']
    }, {
        'question': 'Which of the 7R strategies (Reduce, Reuse, Repair, Refurbish, Remanufacture, Repurpose, Recycle) are applied within a given circular business model - and how effective are they in terms of environmental, economic, or social performance?',
        'usage': ['Select a business model from the dropdown to show the performance indictor details in the bar-chart below.']
    }, {
        'question': 'Which conditions determine whether an existing circular business model can be successfully adapted and implemented in another geographic context?',
        'usage': ['Select a business model from the dropdown to show its details in the network graph.', html.Br(),
            'Select a node or edge to show the details below the network graph.', html.Br(),
            'Select the same node twice to expand it in the network graph.']
    }]
# icq_container is set up with the basic structure for each ICQ and allows easier access to modify the divs later.
icq_container:list[html.Div] = []
app_navbar.children = []
for i, info in enumerate(ICQ_INFO, start = 1):
    icq_container.append(
        html.Div([
                dbc.Row([
                        dbc.Col([
                                html.H2(f'Informal Competency Question {i}', id = f'icq{i}-header', className = 'icq header'),
                                html.H3(info['question'], id = f'icq{i}-subheader', className = 'icq subheader lead'),
                                dbc.Accordion([
                                        dbc.AccordionItem(
                                            info['usage'],
                                            id = f'icq{i}-usage-info',
                                            class_name = 'icq usage-info',
                                            title = 'Usage'
                                        )
                                    ],
                                    start_collapsed = True
                                )
                            ]
                        )
                    ],
                    class_name = 'align-items-center gx-3 gy-1 mb-3'
                )
            ],
            id = f'decide-dashboard-icq{i}',
            className = 'icq'
        )
    )
    # Also extend the navigation bar an item.
    app_navbar.children.append(dbc.NavItem(dbc.NavLink(f'ICQ{i}', href = f'#icq{i}-header', external_link = True)))
for div in icq_container:
    app_container.children.extend([html.Hr(), div]) # type: ignore

# Add the "Explore" section.
explore_container = html.Div([
        dbc.Row([
                dbc.Col([
                        html.H2('Explore', id = 'explore-header', className = 'explore header'),
                        dbc.Accordion([
                                dbc.AccordionItem(
                                    [
                                        'Select the dropdown, type in a search term and select the "Enter" key to search for resources containing the term.', html.Br(),
                                        'This will update the available options in the dropdown with resources whose label or IRI contain the search term.', html.Br(),
                                        'Enter text into the dropdown WITHOUT selecting the "Enter" key to filter the current list of options.', html.Br(),
                                        'To perform a new search (update the available options) select the "Clear" button until it becomes disabled, select the dropdown, type in a search term and select the "Enter" key.', html.Br(),
                                        'Select an option from the dropdown to show in the table ("Details") where the entry is used as a Subject.', html.Br(),
                                        'The details in the second table are read like a sentence in the form of "[Subject] [Property] [Object]", for example "e3-Value_ICP hasGeographicContext Slovenia" or "e3-Value_ICP hasSector Farming".', html.Br(),
                                        'Select an entry in the ("Details") table and select one of "Subject", "Property" or "Object" to update the second table showing where the entry is used as a subject, property or object respectively.', html.Br(),
                                        'Use the filters below the table headers to quickly find specific entries in the tables.', html.Br(),
                                        'The 🌐 icon is placed at the beginning of complex entries, meaning that they can have additional properties assigned to them.'
                                    ],
                                    id = 'explore-usage-info',
                                    class_name = 'explore usage-info',
                                    title = 'Usage'
                                )
                            ],
                            start_collapsed = True
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        )
    ],
    id = 'decide-dashboard-explore',
    className = 'explore'
)
app_navbar.children.append(dbc.NavItem(dbc.NavLink('Explore', href = '#explore-header', external_link = True)))
app_container.children.extend([html.Hr(), explore_container]) # type: ignore

# Add switch to toggle light / dark mode.
app_navbar.children.append(dbc.NavItem(
        html.Span([
                dbc.Label(class_name = 'bi bi-sun-fill', html_for = 'decide-dark-mode-switch'),
                dbc.Switch(id = 'decide-dark-mode-switch', class_name = 'd-inline-block ms-1', value = False, persistence = True),
                dbc.Label(class_name = 'bi bi-moon-stars-fill', html_for = 'decide-dark-mode-switch')
            ],
            className = 'nav-link' # Adding this class so it looks like the other entries in the Navbar.
        )
    )
)

# Callback to toggle between light (off) and dark (on) mode.
clientside_callback(
    ClientsideFunction('clientside', 'switchTheme'),
    Output('decide-dark-mode-switch', 'value'),
    Input('decide-dark-mode-switch', 'value'),
    prevent_initial_call = True
)

#endregion -------------------------------------------------------------------



#region --- ICQ1 -------------------------------------------------------------
# Set up the dashboard part for ICQ1.
#-----------------------------------------------------------------------------

# Main query to get all circular economy business models and their relevant categorizations.
#TODO remove Documented_in and let it be handled via the second "Details" table instead?
ICQ1_MAIN_QUERY = """SELECT ?Business_model ?Region ?Sector ?Strategy ?CEBM_type (?Value_creation_logic AS ?VCL) ?Maturity_level ?Documented_in ?_label_Business_model ?_label_CEBM_type ?_label_Region ?_label_Sector ?_label_Strategy (?_label_Value_creation_logic AS ?_label_VCL) ?_label_Maturity_level ?_label_Documented_in
    WHERE {{
        # Get all circular economy business models.
        ?Business_model rdf:type cebm:BusinessModel .
        ?Business_model cebm:hasCEBMType ?CEBM_type . # Missing in ontology. Also not optional to only return circular business models.
        OPTIONAL {{ ?Business_model rdfs:label ?_label_Business_model . }}
        OPTIONAL {{ ?CEBM_type rdfs:label ?_label_CEBM_type . }}
        # Get optional property information classifying the business model and their optional labels.
        OPTIONAL {{
            ?Business_model cebm:hasGeographicContext ?Region .
            OPTIONAL {{ ?Region rdfs:label ?_label_Region . }}
        }}
        OPTIONAL {{
            ?Business_model cebm:hasSector ?Sector .
            OPTIONAL {{ ?Sector rdfs:label ?_label_Sector . }}
        }}
        OPTIONAL {{
            ?Business_model cebm:appliesStrategy ?Strategy . # Missing in ontology.
            OPTIONAL {{ ?Strategy rdfs:label ?_label_Strategy . }}
        }} 
        OPTIONAL {{
            ?Business_model cebm:usesValueCreationLogic ?Value_creation_logic . # Missing in ontology.
            OPTIONAL {{ ?Value_creation_logic rdfs:label ?_label_Value_creation_logic . }}
        }} 
        OPTIONAL {{
            ?Business_model cebm:hasMaturityLevel ?Maturity_level .
            OPTIONAL {{ ?Maturity_level rdfs:label ?_label_Maturity_level . }}
        }}
        OPTIONAL {{
            ?Business_model cebm:documentedIn ?Documented_in .
            OPTIONAL {{ ?Documented_in rdfs:label ?_label_Documented_in . }}
        }}

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Business_model . }}) &&
            (isLITERAL(?CEBM_type) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?CEBM_type . }}) &&
            (isLITERAL(?Region) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Region . }}) &&
            (isLITERAL(?Sector) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Sector . }}) &&
            (isLITERAL(?Strategy) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Strategy . }}) &&
            (isLITERAL(?Value_creation_logic) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Value_creation_logic . }}) &&
            (isLITERAL(?Maturity_level) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Maturity_level . }}) &&
            (isLITERAL(?Documented_in) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Documented_in . }})
        )
    }}
"""

# Helper UI elements for reuse.
icq1_main_default_headers = [{'id':col, 'name':col} for col in ['Business model', 'Region' , 'Sector', 'Strategy', 'CEBM type', 'Value creation logic', 'Maturity level', 'Documented in']]
icq1_details_info_none = dbc.ListGroupItem('Select an entry in the above table to show its details.', color = 'info')

# Create the UI elements.
# The data is added later in the script to prevent longer loading operations from creating the UI layout.
icq_container[0].children.extend([ # type: ignore
        dcc.Store(id = 'icq1-main-last-selection', data = ''), # Stores the last selected value in the main table.
        dcc.Store(id = 'icq1-details-last-selection', data = ''), # Stores the last selected value in the details table.
        dbc.Row([
                dbc.Col([
                        html.H4('Circular economy business models:'),
                        dcc.Loading(
                            dash_table.DataTable(
                                id = 'icq1-main',
                                data = None,
                                columns = icq1_main_default_headers, # type: ignore # "cannot be assigned ...", but surprisingly it is assignable.
                                export_format = 'csv', export_headers = 'ids',
                                page_action = 'native', page_size = 50,
                                filter_action = 'native', filter_options = {'case': 'insensitive'},
                                sort_action = 'native',
                                fixed_rows = {'headers': True},
                                # Solution to handle content that is too long.
                                style_data = {'overflow': 'hidden', 'textOverflow': 'ellipsis', 'maxWidth': 0},
                                tooltip_duration = None,
                                tooltip_data = []
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        dbc.ListGroup(
                            icq1_details_info_none,
                            id = 'icq1-main-selection-info',
                            class_name = 'icq selection details output',
                            horizontal = 'md'
                        )
                    ],
                    class_name = 'col-md col-12', # On medium size use auto-layout (col-md), otherwise use full width (col-12).
                ),
                dbc.Col([
                        dbc.ButtonGroup([
                                dbc.Button('Show Details',
                                    id = 'icq1-main-selection-show-details',
                                    disabled = True
                                )
                            ]
                        )
                    ],
                    class_name = 'col-auto'
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        html.H4('Details:'),
                        # Also adding a details table to the layout that is updated via callback.
                        dcc.Loading(
                            dash_table.DataTable(
                                id = 'icq1-details',
                                data = None,
                                # Note: the names here must fit to the names returned from the SPARQL query that is executed later.
                                columns = [{'id':col, 'name':col} for col in ['Subject', 'Property' , 'Object']],
                                export_format = 'csv', export_headers = 'ids',
                                page_action = 'native', page_size = 50,
                                filter_action = 'native', filter_options = {'case': 'insensitive'},
                                sort_action = 'native',
                                fixed_rows = {'headers': True},
                                # Solution to handle content that is too long.
                                style_data = {'overflow': 'hidden', 'textOverflow': 'ellipsis', 'maxWidth': 0},
                                tooltip_duration = None,
                                tooltip_data = []
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        dbc.ListGroup(
                            icq1_details_info_none,
                            id = 'icq1-details-selection-info',
                            class_name = 'icq selection details output',
                            horizontal = 'md'
                        )
                    ],
                    class_name = 'col-md col-12', # On medium size use auto-layout (col-md), otherwise use full width (col-12).
                ),
                dbc.Col([
                        dbc.ButtonGroup([
                                dbc.Button(
                                    'Subject',
                                    id = 'icq1-details-selection-as-subject',
                                    disabled = True
                                ),
                                dbc.Button(
                                    'Property',
                                    id = 'icq1-details-selection-as-property',
                                    disabled = True
                                ),
                                dbc.Button(
                                    'Object',
                                    id = 'icq1-details-selection-as-object',
                                    disabled = True
                                )
                            ],
                        )
                    ],
                    class_name = 'col-auto'
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        )
    ]
)

# Callback to update the info section underneath the main table when a cell is selected.
clientside_callback(
    ClientsideFunction('clientside', 'icq1MainTableSelection'),
    Output('icq1-main-last-selection', 'data'),
    Output('icq1-main-selection-info', 'children'),
    Output('icq1-main-selection-show-details', 'disabled'),
    Input('icq1-main', 'active_cell'),
    State('icq1-main', 'tooltip_data'),
    State('icq1-main-selection-info', 'children'), # Added as part of the state to modify the existing element instead of starting from scratch.
    prevent_initial_call = True
)

# Callback to update the details table when the "Show Details" button is selected.
@callback(
    Output('icq1-details', 'data', allow_duplicate = True),
    Output('icq1-details', 'columns', allow_duplicate = True),
    Output('icq1-details', 'tooltip_data', allow_duplicate = True),
    Output('icq1-details', 'page_current', allow_duplicate = True), # Switch to the first page on an update.
    Output('icq1-details-selection-info', 'children', allow_duplicate = True),
    Output('icq1-details-selection-as-subject', 'disabled', allow_duplicate = True),
    Output('icq1-details-selection-as-property', 'disabled', allow_duplicate = True),
    Output('icq1-details-selection-as-object', 'disabled', allow_duplicate = True),
    Input('icq1-main-selection-show-details', 'n_clicks'), # Used only as a trigger, the data itself is irrelevant.
    Input('decide-dashboard-current-user-group', 'data'),
    State('icq1-main-last-selection', 'data'),
    prevent_initial_call = True
)
def icq1_callback_main_info_buttons(show_details_button:int, user_group:str, last_selection:str) -> tuple[list[dict], list[dict], list[dict], int, Component, bool, bool, bool]:
    if 'decide-dashboard-current-user-group' == ctx.triggered_id or not RdfIriResource.valid_url(last_selection):
        return (
            [],
            [{'id':col, 'name':col} for col in ['Subject', 'Property' , 'Object']],
            [],
            0,
            icq1_details_info_none,
            True,
            True,
            True
        )
    if 'icq1-main-selection-show-details' == ctx.triggered_id:
        return (
            *get_iri_resource_statements(last_selection, user_group),
            # 2nd value from *function,
            # 3rd value from *function,
            0,
            icq1_details_info_none,
            True,
            True,
            True
        )
    raise exceptions.PreventUpdate

# Callback to update the info section underneath the details table.
clientside_callback(
    ClientsideFunction('clientside', 'icq1DetailsTableSelection'),
    Output('icq1-details-last-selection', 'data'),
    Output('icq1-details-selection-info', 'children', allow_duplicate = True),
    Output('icq1-details-selection-as-subject', 'disabled', allow_duplicate = True),
    Output('icq1-details-selection-as-property', 'disabled', allow_duplicate = True),
    Output('icq1-details-selection-as-object', 'disabled', allow_duplicate = True),
    Input('icq1-details', 'active_cell'),
    State('icq1-details', 'tooltip_data'),
    State('icq1-details-selection-info', 'children'), # Added as part of the state to modify the existing element instead of starting from scratch.
    prevent_initial_call = True
)

# Callback to update the details table when any of the "Subject", "Property" or "Object" buttons is selected.
@callback(
    Output('icq1-details', 'data', allow_duplicate = True),
    Output('icq1-details', 'columns', allow_duplicate = True),
    Output('icq1-details', 'tooltip_data', allow_duplicate = True),
    Output('icq1-details', 'page_current', allow_duplicate = True), # Switch to the first page on an update.
    Output('icq1-details', 'selected_cells', allow_duplicate = True), # Remove selection so that it isn't highlighted anymore.
    Output('icq1-details', 'active_cell', allow_duplicate = True), # Deactivate the cell so the user can click on it again.
    Input('icq1-details-selection-as-subject', 'n_clicks'),
    Input('icq1-details-selection-as-property', 'n_clicks'),
    Input('icq1-details-selection-as-object', 'n_clicks'),
    Input('decide-dashboard-current-user-group', 'data'),
    State('icq1-details-last-selection', 'data'),
    prevent_initial_call = True
)
def icq1_callback_details_info_buttons(subject_button:int, property_button:int, object_button:int, user_group:str, last_selection:str) -> tuple[list[dict] | NoUpdate, list[dict] | NoUpdate, list[dict] | NoUpdate, int | NoUpdate, list | NoUpdate, None | NoUpdate]:
    query = None
    if 'icq1-details-selection-as-subject' == ctx.triggered_id:
        query = SPARQL_QUERY_S_PO
    elif 'icq1-details-selection-as-property' == ctx.triggered_id:
        query = SPARQL_QUERY_P_SO
    elif 'icq1-details-selection-as-object' == ctx.triggered_id:
        query = SPARQL_QUERY_O_SP
    if not RdfIriResource.valid_url(last_selection) or query is None:
        raise exceptions.PreventUpdate
    return (
        *get_iri_resource_statements(last_selection, user_group, query),
        # 2nd value from *function,
        # 3rd value from *function,
        0,
        [],
        None
    )

#endregion -------------------------------------------------------------------



#region --- ICQ2 -------------------------------------------------------------
# Set up the dashboard part for ICQ2.
#-----------------------------------------------------------------------------

# Main query to get the performance indicator information for the 7R strategies for a specific business model.
# Note: the query has to be finished by executing .format() on it to provide the business model IRI.
ICQ2_MAIN_QUERY = """SELECT ?Business_model ?Strategy ?Dimension ?Value ?_label_Business_model ?_label_Strategy ?_label_Dimension ?_label_Value
    WHERE {{
        VALUES ?Business_model {{ <{business_model}> }}
        ?Business_model cebm:hasCEBMType ?cebm_type . # Missing in ontology. Also not optional to only return circular business models.
        ?Business_model cebm:hasPerformanceIndicator ?pi .
        ?pi cebm:appliesStrategy ?Strategy .
        ?pi cebm:hasDimension ?Dimension .
        ?pi cebm:performanceValue ?Value .

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Business_model . }}) &&
            (isLITERAL(?cebm_type) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?cebm_type . }}) &&
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?pi . }}) &&
            (isLITERAL(?Strategy) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Strategy . }}) &&
            (isLITERAL(?Dimension) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Dimension . }}) &&
            (isLITERAL(?Value) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Value . }})
        )

        OPTIONAL {{ ?Business_model rdfs:label ?_label_Business_model . }}
        OPTIONAL {{ ?Strategy rdfs:label ?_label_Strategy . }}
        OPTIONAL {{ ?Dimension rdfs:label ?_label_Dimension . }}
        OPTIONAL {{ ?Value rdfs:label ?_label_Value . }}
    }}
"""

# The data frame is used to initialize an empty chart. It uses wide form and is initialized with empty (NaN) values.
ICQ2_DF_INITIAL = pd.DataFrame([
        [strategy, *[npy.nan for dimension in IRIS_DIMENSION]] for strategy in IRIS_STRATEGY.values()
    ],
    index = range(0, len(IRIS_STRATEGY)),
    columns = ['Strategy', *IRIS_DIMENSION.values()]
)

# Create the UI elements.
# The data is added later in the script to prevent longer loading operations from creating the UI layout.
icq_container[1].children.extend([ # type: ignore
        dbc.Row([
                dbc.Col([
                        dcc.Loading(
                            dcc.Dropdown(
                                options = [],
                                id = 'icq2-bm-select',
                                placeholder = 'Select a business model',
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        dcc.Loading(
                            dcc.Graph(id = 'icq2-bar'), # Figure updated as part of the initialization callback.
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        )
    ]
)

# Callback to update the bar chart when a business model is selected.
@callback(
    Output('icq2-bar', 'figure'),
    Input('icq2-bm-select', 'value'),
    Input('decide-dashboard-current-user-group', 'data')
)
def icq2_callback_update_barchart(business_model_iri:str, user_group:str): # -> Figure
    if business_model_iri is not None:
        # We get a data frame in wide form.
        performance_indicator_bindings = sq.execute_query(ICQ2_MAIN_QUERY.format(business_model = business_model_iri, user_group = user_group))
        performance_indicator_df = SparqlResultsToWideDataFrame(DERIVE_MISSING_LABELS).transform(performance_indicator_bindings, 'Strategy', 'Dimension', 'Value',
            missing_value = npy.nan,
            initialized = {k1: {k2: npy.nan for k2 in IRIS_DIMENSION.values()} for k1 in IRIS_STRATEGY.values()})
    else:
        performance_indicator_df = ICQ2_DF_INITIAL.copy()
    # We modify the IRIs in the data frame to be easier to read labels instead.
    performance_indicator_df.rename(columns = dict(zip(IRIS_DIMENSION.values(), IRIS_DIMENSION.keys())), inplace = True)
    performance_indicator_df.replace(to_replace = {'Strategy': dict(zip(IRIS_STRATEGY.values(), IRIS_STRATEGY.keys()))}, inplace = True)
    return px.bar(performance_indicator_df, x = 'Strategy', y = list(IRIS_DIMENSION.keys()), barmode = 'group', labels = {'value': 'Value', 'variable': 'Dimension'}, color_discrete_sequence = ['#144', '#588', '#7bb'])

#endregion -------------------------------------------------------------------



#region --- ICQ3 -------------------------------------------------------------
# Set up the dashboard part for ICQ3.
#-----------------------------------------------------------------------------

# Main query to get the details surrounding a specific RDF Resource (business model at first).
# Note: the query has to be finished by executing .format() on it to provide the resource IRI.
ICQ3_MAIN_QUERY = """SELECT ?Subject ?Property ?Object ?_label_Subject ?_label_Property ?_label_Object
    WHERE {{
        VALUES ?Subject {{ <{subject}> }}
        ?Subject ?Property ?Object .

        # Ignoring various things that clutter up the result.
        # Note: FILTER must return a true value for bindings to KEEP, so a few of these have been reduced using De Morgan's laws.
        FILTER (
            # Filter out x owl:sameAs x.
            ((?Property != owl:sameAs) || (?Subject != ?Object)) &&
            # Filter out all properties that uses the default RDF Transformation namespace.
            (!STRSTARTS(STR(?Property), "http://example.org/cebm/adoxx-rdf/#")) &&
            # Filter out all cebm:hasRevenueStream properties, as they create too many results.
            (?Property != cebm:hasRevenueStream) &&
            # Filter out x rdf:type owl:Thing, because everything is of type owl:Thing.
            ((?Property != rdf:type) || (?Object != owl:Thing))
        )

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Subject . }}) &&
           #(EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_property ?Property . }}) &&
            (isLITERAL(?Object) || EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Object . }})
        )

        # Get optional labels for each of them.
        OPTIONAL {{ ?Subject rdfs:label ?_label_Subject . }}
        OPTIONAL {{ ?Property rdfs:label ?_label_Property . }}
        OPTIONAL {{ ?Object rdfs:label ?_label_Object . }}
    }}
"""

# Helper UI elements for reuse.
icq3_details_none = dbc.ListGroupItem('Select a node or edge in the above graph to show its details.', color = 'info')

# Create the UI elements.
# The data is added later in the script to prevent longer loading operations from creating the UI layout.
icq_container[2].children.extend([ # type: ignore
        dcc.Store(id = 'icq3-last-selected-data', data = {}),
        dcc.Store(id = 'icq3-known-node-ids', data = []),
        dbc.Row([
                dbc.Col([
                        dcc.Loading(
                            dcc.Dropdown(
                                options = [],
                                id = 'icq3-bm-select',
                                placeholder = 'Select a business model'
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        html.Div(
                            'Select layout for network graph:',
                            id = 'icq3-layout-label',
                            className = 'icq usage-info'
                        ),
                        dcc.Loading(
                            dcc.Dropdown(
                                options = list(PREDEFINED_LAYOUT_CONFIGURATIONS.keys()),
                                value = STARTING_NETWORK_GRAPH_LAYOUT if STARTING_NETWORK_GRAPH_LAYOUT in PREDEFINED_LAYOUT_CONFIGURATIONS.keys() else 'concentric',
                                id = 'icq3-layout-select',
                                placeholder = 'Select a layout for the network graph',
                                clearable = False
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        dcc.Loading(
                            cyto.Cytoscape(
                                id = 'icq3-network-graph',
                                className = 'icq network-graph cytoscape mx-auto',
                                style = {'width': '100%'}, # Necessary for the graph to fill the provided area. Control the actual width in the CSS using max-width.
                                #layout = use_layout_for_cytoscape, # Layout is set later via callback.
                                autoRefreshLayout = True, responsive = True,
                                elements = [],
                                stylesheet = CYTOSCAPE_RDF_STYLESHEET + CYTOSCAPE_CEBM_STYLESHEET
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        dbc.ListGroup(icq3_details_none,
                            id = 'icq3-network-graph-info',
                            class_name = 'icq network-graph details output',
                            horizontal = 'md'
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        )
    ]
)

# Callback to initialize the network graph when a business model is selected.
@callback(
    Output('icq3-network-graph', 'elements', allow_duplicate = True),
    Output('icq3-known-node-ids', 'data', allow_duplicate = True),
    Input('icq3-bm-select', 'value'),
    Input('decide-dashboard-current-user-group', 'data'),
    prevent_initial_call = True
)
def icq3_callback_init_graph(business_model_iri:str, user_group:str) -> tuple[list[dict], list[Any]]:
    if business_model_iri is not None:
        business_model_bindings = sq.execute_query(ICQ3_MAIN_QUERY.format(subject = business_model_iri, user_group = user_group))
        business_model_2d_dict = SparqlResultsToWideDict(DERIVE_MISSING_LABELS).transform(business_model_bindings, 'Subject', 'Property', 'Object')
        graph_elements = cytoscape_elements_from_2d_dict(business_model_2d_dict)
        # The assumption here is that edges don't have an 'id'.
        known_nodes = [elem['data']['id'] for elem in graph_elements if elem['data'].get('id', None)]
    else:
        graph_elements = []
        known_nodes = []
    return graph_elements, known_nodes

# Callback to change the layout of the network graph.
# This is not handled in a clientside_callback since the predefined configurations are also used in other parts that are realized with Python.
@callback(
    Output('icq3-network-graph', 'layout'),
    Input('icq3-layout-select', 'value')
)
def icq3_callback_update_layout(layout:str):
    return PREDEFINED_LAYOUT_CONFIGURATIONS.get(layout, no_update)

# Callback to update the data of the last selected element when a node is selected (tapped).
clientside_callback(
    ClientsideFunction('clientside', 'icq3UpdateLastSelection'),
    Output('icq3-last-selected-data', 'data', allow_duplicate = True),
    Input('icq3-network-graph', 'tapNodeData'),
    prevent_initial_call = True
)

# Callback to update the info section underneath the network graph when a node is selected (tapped).
clientside_callback(
    ClientsideFunction('clientside', 'icq3NodeUpdateDetailsSection'),
    Output('icq3-network-graph-info', 'children', allow_duplicate = True),
    Input('icq3-network-graph', 'tapNodeData'),
    prevent_initial_call = True
)

# Callback to extend the graph when the same node is selected (tapped) twice in succession.
@callback(
    Output('icq3-network-graph', 'elements', allow_duplicate = True),
    Output('icq3-known-node-ids', 'data', allow_duplicate = True),
    Input('icq3-network-graph', 'tapNodeData'),
    State('decide-dashboard-current-user-group', 'data'),
    State('icq3-network-graph', 'elements'),
    State('icq3-last-selected-data', 'data'),
    State('icq3-known-node-ids', 'data'),
    prevent_initial_call = True
)
def icq3_callback_select_node_twice(node_data:dict, user_group:str, graph_elements:list[dict], last_selected_data:dict[str, Any], known_nodes:list[Any]) -> tuple[list[dict] | NoUpdate, list | NoUpdate]:
    # Load more nodes into the graph when the same node is selected twice.
    # We don't use node_data.get('id', None), as we are then comparing the id against the 'id' of the last selected, which if missing also gets None.
    if 'id' in node_data and (node_data['id'] == last_selected_data.get('id', None)) and node_data.get('iri', None):
        subject_bindings = sq.execute_query(ICQ3_MAIN_QUERY.format(subject = node_data['iri'], user_group = user_group))
        subject_2d_dict = SparqlResultsToWideDict(DERIVE_MISSING_LABELS).transform(subject_bindings, 'Subject', 'Property', 'Object')
        elements_to_add = cytoscape_elements_from_2d_dict(subject_2d_dict)
        # Filter out any nodes that are already in the graph, since we don't want them twice (with the same id).
        # known_nodes should not include the value None, so the None from elem['data'].get('id', None) should prevent filtering out edges.
        elements_to_add = filter(lambda elem: elem['data'].get('id', None) not in known_nodes, elements_to_add)
        graph_elements.extend(elements_to_add)
        # The assumption here is that edges don't have an 'id'.
        known_nodes.extend([elem['data']['id'] for elem in elements_to_add if elem['data'].get('id', None)])
        return (graph_elements, known_nodes)
    return (no_update, no_update)

# Callback to update the data of the last selected element when an edge is selected (tapped).
clientside_callback(
    ClientsideFunction('clientside', 'icq3UpdateLastSelection'),
    Output('icq3-last-selected-data', 'data', allow_duplicate = True),
    Input('icq3-network-graph', 'tapEdgeData'),
    prevent_initial_call = True
)

# Callback to update the info section underneath the network graph when an edge is selected (tapped).
clientside_callback(
    ClientsideFunction('clientside', 'icq3EdgeUpdateDetailsSection'),
    Output('icq3-network-graph-info', 'children', allow_duplicate = True),
    Input('icq3-network-graph', 'tapEdgeData'),
    prevent_initial_call = True
)

# Also enable the callbacks to update the 
if not config_dashboard.getboolean('disableNetworkGraphMouseOver'):
    # Callback to update the info section underneath the network graph when a node is selected (tapped).
    clientside_callback(
        ClientsideFunction('clientside', 'icq3NodeUpdateDetailsSection'),
        Output('icq3-network-graph-info', 'children', allow_duplicate = True),
        Input('icq3-network-graph', 'mouseoverNodeData'),
        prevent_initial_call = True
    )

    # Callback to update the info section underneath the network graph when hovering over an edge.
    clientside_callback(
        ClientsideFunction('clientside', 'icq3EdgeUpdateDetailsSection'),
        Output('icq3-network-graph-info', 'children', allow_duplicate = True),
        Input('icq3-network-graph', 'mouseoverEdgeData'),
        prevent_initial_call = True
    )

#endregion -------------------------------------------------------------------



#region --- Explore ----------------------------------------------------------
# Set up the dashboard part for Explore.
#-----------------------------------------------------------------------------

EXPLORE_SEARCH_FOR_RESOURCE = """SELECT DISTINCT ?Iri ?_label_Iri
    WHERE {{
        BIND (LCASE("{search_value}") AS ?searchTerm)

        {{
            ?Iri ?_a [] .
        }} UNION {{
            [] ?_a ?Iri .
            FILTER (isIRI(?Iri))
        }}
        BIND (STR(?Iri) AS ?_str_Iri)
        # Get optional label.
        OPTIONAL {{ ?Iri rdfs:label ?label . }}
        # If there is no label then derive one using the same logic as RdfIriResource does (to not confuse the user).
        BIND (IF(BOUND(?label), ?label, REPLACE(REPLACE(?_str_Iri, "^[^#]*#", ""), "_", " ")) AS ?_label_Iri)

        # Filer based on search term, ignoring case.
        FILTER (
            CONTAINS(LCASE(?_str_Iri), ?searchTerm) ||
            CONTAINS(LCASE(?_label_Iri), ?searchTerm)
        )

        # Make sure that the user group has access to the resources.
        # Note: We use property paths because the rule that allows the access to specific resources can be in different groups (group inheritance).
        FILTER (
            (EXISTS {{ <{user_group}> cebmauth:inherits_from* / cebmauth:allowed_resource_iri ?Iri . }})
        )
    }}
    LIMIT 101 # Limiting to 101 so that we can test if there's more than 100.
"""

explore_search_details_info_none = dbc.ListGroupItem('Select an entry in the above dropdown to show its details.', color = 'info')
explore_details_info_none = dbc.ListGroupItem('Select an entry in the above table to show its details.', color = 'info')

# Create the UI elements.
# The data is added through user interaction.
explore_container.children.extend([ # type: ignore
        dcc.Store(id = 'explore-search-full-entry', data = ''), # Stores the value to use for the search.
        dcc.Store(id = 'explore-details-last-selection', data = ''), # Stores the last selected value in the details table.
        dbc.Row([
                dbc.Col([
                        dcc.Loading(
                            dcc.Dropdown(
                                options = [],
                                id = 'explore-search',
                                placeholder = 'Type in search term and select "Enter" key'
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ],
                    class_name = 'col-md col-12', # On medium size use auto-layout (col-md), otherwise use full width (col-12).
                ),
                dbc.Col([
                        dbc.ButtonGroup([
                                dbc.Button('Clear',
                                    id = 'explore-search-clear',
                                    disabled = True
                                )
                            ]
                        )
                    ],
                    class_name = 'col-auto'
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col(
                    id = 'explore-search-alerts',
                    class_name = 'col-md col-12', # On medium size use auto-layout (col-md), otherwise use full width (col-12).
                )
            ],
            #class_name = 'align-items-center gx-3 gy-1 mb-3' # Since the row doesn't contain any content at first it should also not take up any space.
        ),
        dbc.Row([
                dbc.Col([
                        dbc.ListGroup(
                            explore_search_details_info_none,
                            id = 'explore-search-info',
                            class_name = 'explore selection details output',
                            horizontal = 'md'
                        )
                    ],
                    class_name = 'col-md col-12', # On medium size use auto-layout (col-md), otherwise use full width (col-12).
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        html.H4('Details:'),
                        # Also adding a details table to the layout that is updated via callback.
                        dcc.Loading(
                            dash_table.DataTable(
                                id = 'explore-details',
                                data = None,
                                # Note: the names here must fit to the names returned from the SPARQL query that is executed later.
                                columns = [{'id':col, 'name':col} for col in ['Subject', 'Property' , 'Object']],
                                export_format = 'csv', export_headers = 'ids',
                                page_action = 'native', page_size = 50,
                                filter_action = 'native', filter_options = {'case': 'insensitive'},
                                sort_action = 'native',
                                fixed_rows = {'headers': True},
                                # Solution to handle content that is too long.
                                style_data = {'overflow': 'hidden', 'textOverflow': 'ellipsis', 'maxWidth': 0},
                                tooltip_duration = None,
                                tooltip_data = []
                            ),
                            delay_show = 100,
                            overlay_style = {'visibility': 'visible', 'filter': 'blur(2px)'}
                        )
                    ]
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        ),
        dbc.Row([
                dbc.Col([
                        dbc.ListGroup(
                            explore_details_info_none,
                            id = 'explore-details-selection-info',
                            class_name = 'explore selection details output',
                            horizontal = 'md'
                        )
                    ],
                    class_name = 'col-md col-12', # On medium size use auto-layout (col-md), otherwise use full width (col-12).
                ),
                dbc.Col([
                        dbc.ButtonGroup([
                                dbc.Button(
                                    'Subject',
                                    id = 'explore-details-selection-as-subject',
                                    disabled = True
                                ),
                                dbc.Button(
                                    'Property',
                                    id = 'explore-details-selection-as-property',
                                    disabled = True
                                ),
                                dbc.Button(
                                    'Object',
                                    id = 'explore-details-selection-as-object',
                                    disabled = True
                                )
                            ],
                        )
                    ],
                    class_name = 'col-auto'
                )
            ],
            class_name = 'align-items-center gx-3 gy-1 mb-3'
        )
    ]
)

# Updating explore-search-full-entry.data ("full search entry") is taken care by a clientside event listener to capture the "Enter" key.

# Update the list of available options when the "full search entry" was updated or the user group changes.
@callback(
    Output('explore-search', 'options', allow_duplicate = True),
    Output('explore-search-clear', 'disabled', allow_duplicate = True),
    Output('explore-search-alerts', 'children', allow_duplicate = True),
    Input('explore-search-full-entry', 'data'),
    Input('decide-dashboard-current-user-group', 'data'),
    prevent_initial_call = True
)
def explore_callback_update_dropdown(search_value:str, user_group:str) -> tuple[list[Any] | NoUpdate, bool | NoUpdate, list[Component] | Component | NoUpdate]:
    if search_value:
        explore_bindings = sq.execute_query(EXPLORE_SEARCH_FOR_RESOURCE.format(search_value = search_value, user_group = user_group))
        explore_df = SparqlResultsToDataFrame(DERIVE_MISSING_LABELS).transform(explore_bindings)
        return (
            [
                {
                    'label': entry.label if entry.label else entry.full_iri,
                    'title': f'{entry.label}\n\n{entry.full_iri}',
                    'value': entry.full_iri
                } for entry in explore_df['Iri'] if isinstance(entry, RdfIriResource)
            ],
            not len(explore_df) > 0,
            [
                dbc.Alert(
                    'The provided search term resulted in more than 100 results. Only the first 101 are shown. Please clear the search and provide a more specific search term.',
                    id = 'explore-search-alert-too-many-results',
                    color = "warning"
                )
            ] if len(explore_df) > 100 else []
        )
    return no_update, no_update, no_update

# Clear the dropdown and the "full search entry".
clientside_callback(
    ClientsideFunction('clientside', 'exploreClearOptions'),
    Output('explore-search', 'options', allow_duplicate = True),
    Output('explore-search', 'value'),
    Output('explore-search-full-entry', 'data'),
    Output('explore-search-clear', 'disabled', allow_duplicate = True),
    Output('explore-search-alerts', 'children', allow_duplicate = True),
    Output('explore-search-info', 'children', allow_duplicate = True),
    Input('explore-search-clear', 'n_clicks'),
    State('explore-search-info', 'children'),
    prevent_initial_call = True
)

# Callback to update the info section underneath the explore search dropdown when an entry is selected.
clientside_callback(
    ClientsideFunction('clientside', 'exploreSearchSelection'),
    Output('explore-search-info', 'children', allow_duplicate = True),
    Input('explore-search', 'value'),
    State('explore-search-info', 'children'),
    prevent_initial_call = True
)

# Callback to update the details table when something from the dropdown is selected.
@callback(
    Output('explore-details', 'data', allow_duplicate = True),
    Output('explore-details', 'columns', allow_duplicate = True),
    Output('explore-details', 'tooltip_data', allow_duplicate = True),
    Output('explore-details', 'page_current', allow_duplicate = True), # Switch to the first page on an update.
    Output('explore-details-selection-info', 'children', allow_duplicate = True),
    Output('explore-details-selection-as-subject', 'disabled', allow_duplicate = True),
    Output('explore-details-selection-as-property', 'disabled', allow_duplicate = True),
    Output('explore-details-selection-as-object', 'disabled', allow_duplicate = True),
    Input('explore-search', 'value'),
    Input('decide-dashboard-current-user-group', 'data'),
    prevent_initial_call = True
)
def explore_callback_search_value(iri_value:str, user_group:str) -> tuple[list[dict], list[dict], list[dict], int, Component, bool, bool, bool]:
    if 'decide-dashboard-current-user-group' == ctx.triggered_id or not RdfIriResource.valid_url(iri_value):
        return (
            [],
            [{'id':col, 'name':col} for col in ['Subject', 'Property' , 'Object']],
            [],
            0,
            explore_details_info_none,
            True,
            True,
            True
        )
    if 'explore-search' == ctx.triggered_id:
        return (
            *get_iri_resource_statements(iri_value, user_group),
            # 2nd value from *function,
            # 3rd value from *function,
            0,
            explore_details_info_none,
            True,
            True,
            True
        )
    raise exceptions.PreventUpdate

# Callback to update the info section underneath the details table.
clientside_callback(
    ClientsideFunction('clientside', 'exploreDetailsTableSelection'),
    Output('explore-details-last-selection', 'data'),
    Output('explore-details-selection-info', 'children', allow_duplicate = True),
    Output('explore-details-selection-as-subject', 'disabled', allow_duplicate = True),
    Output('explore-details-selection-as-property', 'disabled', allow_duplicate = True),
    Output('explore-details-selection-as-object', 'disabled', allow_duplicate = True),
    Input('explore-details', 'active_cell'),
    State('explore-details', 'tooltip_data'),
    State('explore-details-selection-info', 'children'), # Added as part of the state to modify the existing element instead of starting from scratch.
    prevent_initial_call = True
)

# Callback to update the details table when any of the "Subject", "Property" or "Object" buttons is selected.
@callback(
    Output('explore-details', 'data', allow_duplicate = True),
    Output('explore-details', 'columns', allow_duplicate = True),
    Output('explore-details', 'tooltip_data', allow_duplicate = True),
    Output('explore-details', 'page_current', allow_duplicate = True), # Switch to the first page on an update.
    Output('explore-details', 'selected_cells', allow_duplicate = True), # Remove selection so that it isn't highlighted anymore.
    Output('explore-details', 'active_cell', allow_duplicate = True), # Deactivate the cell so the user can click on it again.
    Input('explore-details-selection-as-subject', 'n_clicks'),
    Input('explore-details-selection-as-property', 'n_clicks'),
    Input('explore-details-selection-as-object', 'n_clicks'),
    Input('decide-dashboard-current-user-group', 'data'),
    State('explore-details-last-selection', 'data'),
    prevent_initial_call = True
)
def explore_callback_details_info_buttons(subject_button:int, property_button:int, object_button:int, user_group:str, last_selection:str) -> tuple[list[dict] | NoUpdate, list[dict] | NoUpdate, list[dict] | NoUpdate, int | NoUpdate, list | NoUpdate, None | NoUpdate]:
    query = None
    if 'explore-details-selection-as-subject' == ctx.triggered_id:
        query = SPARQL_QUERY_S_PO
    elif 'explore-details-selection-as-property' == ctx.triggered_id:
        query = SPARQL_QUERY_P_SO
    elif 'explore-details-selection-as-object' == ctx.triggered_id:
        query = SPARQL_QUERY_O_SP
    if not RdfIriResource.valid_url(last_selection) or query is None:
        raise exceptions.PreventUpdate
    return (
        *get_iri_resource_statements(last_selection, user_group, query),
        # 2nd value from *function,
        # 3rd value from *function,
        0,
        [],
        None
    )

#endregion -------------------------------------------------------------------



#region --- Init Dash data ---------------------------------------------------
# Initializes the Dash components with data.
# We do this after the rest is set up so that the UI doesn't block.
# Also most of these are based on switching the user group.
#-----------------------------------------------------------------------------

# Initialize Group selection dropdown via callback when the site is loaded.
@callback(
    Output('decide-dashboard-user-group-selection', 'options'),
    Output('decide-dashboard-user-group-selection', 'value'),
    Input('url', 'pathname') # Using a dcc.Location as input will execute this when the page is loaded or re-loaded.
)
def init_user_groups_dropdown(url_pathname:str):
    USER_GROUP_QUERY = """SELECT ?User_group
    WHERE {
        ?User_group rdf:type cebmauth:Group .
    }
    """
    user_groups_bindings = sq.execute_query(USER_GROUP_QUERY)
    user_groups_df = SparqlResultsToDataFrame(DERIVE_MISSING_LABELS).transform(user_groups_bindings)
    user_group_list = user_groups_df['User_group'].to_list()
    return user_group_list, (user_group_list[0] if len(user_group_list) else None)

# Initialize data table of ICQ1 via callback when the site is loaded..
@callback(
    Output('icq1-main', 'data'),
    Output('icq1-main', 'columns'),
    Output('icq1-main', 'tooltip_data'),
    Input('decide-dashboard-current-user-group', 'data')
)
def icq1_init_main_table(user_group:str) -> tuple[list[dict], list[Any], list[dict]]:
    if user_group is not None:
        cebm_bindings = sq.execute_query(ICQ1_MAIN_QUERY.format(user_group = user_group))
        cebm_df = SparqlResultsToDataFrame(DERIVE_MISSING_LABELS).transform(cebm_bindings)
        columns = get_columns_definition(cebm_df, {'hideable': True})
        tooltips = [
            {
                col: {'value': str(getattr(row, col))} for col in row._fields # type: ignore
            } for row in cebm_df.itertuples(False)
        ]
        # Change the values from IRIs to more readable labels when possible.
        cebm_df_labeled = dataframe_labels_for_values(cebm_df, '🌐 ')
        return cebm_df_labeled.to_dict('records'), columns, tooltips
    return (None, icq1_main_default_headers, [])

# Initialize dropdown of ICQ2, ICQ3 and ICQ4 via callback when the site is loaded.
#TODO since the "list of business models" is used a lot it might be useful to have a dcc.Store that stores the options and when that changes use clientside_callback for each output to update those (or: https://dash.plotly.com/advanced-callbacks#setting-properties-directly). Alternatively since a lot of the ICQ start from a Business model -> use the one selected in ICQ1, this would reduce the amount of repeating inputs and UI elements, but also would require to restructure the app a bit.
@callback(
    Output('icq2-bm-select', 'options'),
    Output('icq3-bm-select', 'options'),
    Input('decide-dashboard-current-user-group', 'data')
)
def icq2_3_init_bm_dropdown(user_group:str) -> tuple[list[Any], list[Any]]:
    if user_group is not None:
        business_model_bindings = sq.execute_query(SPARQL_QUERY_S_OF_RDF_TYPE.format(IRI_BUSINESS_MODEL.full_iri, user_group = user_group))
        business_model_df = SparqlResultsToDataFrame(DERIVE_MISSING_LABELS).transform(business_model_bindings)
        business_model_iris = [getattr(x, 'full_iri', x) for x in business_model_df['Subject'].to_list()]
        return business_model_iris, business_model_iris
    return [], []

#endregion -------------------------------------------------------------------



#region --- Main -------------------------------------------------------------
# Code to execute when this script is executed as the __main__ script.
#-----------------------------------------------------------------------------

if __name__ == '__main__':
    # Get the port from the configuration or use default port 8050.
    PORT = config_dashboard.getint('dashboardPort', 8050)
    # Try to open the dashboard page in the webbrowser.
    try:
        import os
        # Checking this environment variables makes the browser window open only ONCE.
        # Otherwise when changing the code in debug mode it would open the page again and again and again.
        if not os.environ.get('WERKZEUG_RUN_MAIN'):
            from threading import Timer
            import webbrowser
            # Opening on a timer to let the app start first.
            Timer(1, webbrowser.open, [f'http://localhost:{PORT}{DASHBOARD_URL_PATH}']).start()
            print(f'Link to page: http://localhost:{PORT}{DASHBOARD_URL_PATH}')
    except Exception:
        pass
    # Start the Dash app.
    # Dash (Flask?) and the debugger don't like each other, but not sure what to exactly change for it to work better ... (started_through_debugger)
    app.run(debug = debug, host = '0.0.0.0', port = PORT)

#endregion -------------------------------------------------------------------
