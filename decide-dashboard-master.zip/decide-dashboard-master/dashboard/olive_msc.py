# Python internal modules.
from typing import Any, overload

# 3rd party modules.
import requests as req



#region ------------------------- Olive MSC ----------------------------------
# Class with functions to make working with the Olive MSC easier in Python.
#-----------------------------------------------------------------------------



class OliveError(req.RequestException):
    """An error occurred while calling an operation of the Olive MSC."""

    # IMPORTANT: the default values here are only a hint! They are actually set in the one function that implements these overloads!
    @overload
    def __init__(self, status:int | None = None, message:str | None = None, *, request:req.Request | None = None, response:req.Response | None = None): ... # type: ignore

    def __init__(self, *args, **kwargs):
        status = kwargs.pop('status') if 'status' in kwargs else (args[0] if len(args) > 0 else None)
        message = kwargs.pop('message') if 'message' in kwargs else (args[1] if len(args) > 1 else None)
        super().__init__(status, message, **kwargs)



class OliveMsc():
    """Class providing functions to make calling operations on an Olive MSC easier."""

    def __init__(self, endpoint:str):
        """Initializes a new OliveMsc object which can then be used to call operations.

        The object retrieves a list of all microservices and their identifiers and caches them.
        Should you expect that new microservices have been added or the name / ID of existing ones changed,
        then call the `olive_update_mapping_cache()` method.

        Args:
            endpoint (str): The REST endpoint of the Olive MSC.
                For example: `http://localhost:7300/micro-service-controller-rest/rest`

        Raises:
            TypeError: Raised when a mandatory parameter is missing.
        """
        if (not isinstance(endpoint, str)):
            raise TypeError('The `endpoint` parameter must be a text (of type `str`).')
        self.endpoint = endpoint if (endpoint.endswith('/')) else f'{endpoint}/'
        self.id_to_name_cache:dict[str, str] = {}
        self.name_to_id_cache:dict[str, str] = {}
        self.olive_update_mapping_cache()

    @classmethod
    def dict_to_olive_input(cls, d:dict[str, Any]):
        """Transforms a simple dictionary of keys (inputs) and their values to the input structure that the Olive MSC expects."""
        return {k: {'value': v} for k, v in d.items()}

    @classmethod
    def get_olive_response(cls, resp:req.Response) -> dict[str, Any]:
        """Processes the response from the Olive MSC and returns the data as a dictionary.

        How the data looks inside of the dictionary depends on the details of the called operation.
        It will also raise errors if something is wrong with the response.

        Args:
            resp (Response): The response object to process.

        Raises:
            OliveError: When the response from the Olive MSC had a non-0 status.

        Returns:
            dict[str, Any]: The response data, i.e. the value of the 'data' key from the response.
        """
        # Raise an HTTPError based on the response status code.
        resp.raise_for_status()
        # As far as we know the Olive MSC ALWAYS returns a JSON.
        resp_dict = resp.json()
        status = resp_dict.get('status', 0)
        if (status):
            msg = resp_dict.get('error', None)
            raise OliveError(status, msg.replace('\n', ' ') if isinstance(msg, str) else msg, response = resp)
        return resp_dict.get('data', {})

    @property
    def name_clash(self) -> bool:
        """True when more than one Microservices has the same name.
        If that is the case then looking up the identifier for a service name will return one of the possible results."""
        return len(self.id_to_name_cache) != len(self.name_to_id_cache)

    def olive_update_mapping_cache(self) -> None:
        """Updates `id_to_name_cache` and `name_to_id_cache`.

        Execute this method when you think that new microservices have been added to the Olive MSC
        or the names / IDs of existing microservices might have changed.

        Raises:
            HTTPError: When the response contained a non-successful HTTP status code.
            OliveOpError: When the response from the Olive MSC had a non-0 status.
        """
        resp = req.get(f'{self.endpoint}msc/retrieveAllMicroservices')
        # The following also raises errors if something is amiss.
        data:dict = OliveMsc.get_olive_response(resp)
        # Get the mapping and update the cache.
        self.id_to_name_cache = {}
        for id, ms_obj in data.items():
            if isinstance(ms_obj, dict):
                self.id_to_name_cache[id] = ms_obj['name']
            else:
                self.id_to_name_cache[id] = ms_obj
        # Update the other cache.
        self.name_to_id_cache = {v: k for k, v in self.id_to_name_cache.items()}

    def olive_call_operation(self, service:str, operation:str, input:dict[str, Any]) -> dict:
        """Calls an operation provided by the Olive MSC and returns.

        Updates the cache if the service is not known in the object's cache.

        Args:
            service (str): The name or identifier of the service. The identifier takes precedence.
            operation (str): The identifier of the operation to call.
            input (dict[str, Any]): The input to send to the operation.
                This should have the simple structure where keys are the name of the input and their values are the value to use for them.
                The method then converts this to the data structure that the Olive MSC wants.

        Raises:
            HTTPError: When the response contained a non-successful HTTP status code.
            OliveOpError: When the response from the Olive MSC had a non-0 status.

        Returns:
            dict: The output from the operation, i.e. the value of the 'data' key from the response.
        """
        # Get the ID of the service.
        if (service not in self.id_to_name_cache) and (service not in self.name_to_id_cache):
            self.olive_update_mapping_cache()
        service_id = service if service in self.id_to_name_cache else self.name_to_id_cache.get(service, None)
        if not service_id:
            raise OliveError(None, f'No microservice known with name / ID: {service}')
        # Transform the input into what the Olive MSC wants.
        olive_input = OliveMsc.dict_to_olive_input(input)
        # Call the operation of the service.
        resp = req.post(f'{self.endpoint}msc/callMicroserviceForced?microserviceId={service_id}&operationId={operation}', json = olive_input)
        # The following also raises errors if something is amiss.
        return OliveMsc.get_olive_response(resp)

#endregion -------------------------------------------------------------------
