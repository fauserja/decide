# Python internal modules.
from abc import ABC, abstractmethod
import ast
import copy
from typing import Any, Self, override
from urllib.parse import urlparse

# 3rd party modules.
import pandas as pd

# Other code from this project.
import olive_msc as olive



# Note: Type-checking is disabled for certain lines (# type: ignore).
# In those cases we expect it either to work or otherwise to exit with an exception, since we can't handle it.

# Common prefixes used for SPARQL in this project:
"""
PREFIX adoxx_mm: <https://www.adoxx.org/mm#>
PREFIX cebm:     <http://example.org/cebm#>
PREFIX cebmauth: <http://example.org/cebm/auth/#>
PREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>
PREFIX owl:      <http://www.w3.org/2002/07/owl#>
PREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>
PREFIX xml:      <http://www.w3.org/XML/1998/namespace>
PREFIX xsd:      <http://www.w3.org/2001/XMLSchema#>
"""



#region --- SparqlUtils ------------------------------------------------------
# Class to make creating SPARQL code easier.
#-----------------------------------------------------------------------------

class SparqlUtils():
    """Utility class to deal with SPARQL things in general.
    
    Other classes, like `SparqlQueryOlive`, inherit from this and provide more specific utilities.
    """

    default_sparql_prefixes = {
        'adoxx_mm:': 'https://www.adoxx.org/mm#',
        'cebm:': 'http://example.org/cebm#',
        'cebmauth:': 'http://example.org/cebm/auth/#',
        #'cv:': 'http://www.comvantage.eu/mm#',
        'mm:': 'http://example.org/cebm/adoxx-rdf/#',
        'owl:': 'http://www.w3.org/2002/07/owl#',
        'rdf:': 'http://www.w3.org/1999/02/22-rdf-syntax-ns#',
        'rdfs:': 'http://www.w3.org/2000/01/rdf-schema#',
        'xml:': 'http://www.w3.org/XML/1998/namespace',
        'xsd:': 'http://www.w3.org/2001/XMLSchema#'
    }
    """Default SPARQL prefixes added to every SPARQL query or set of update commands."""

    def __init__(self, no_label_namespace:str | None = None):
        """A new utility object to make handling some SPARQL things easier.

        Currently this is:
        * Providing a collection of common namespace prefixes.
        * Writing SPARQL query or update code.

        Args:
            no_label_prefix (`str` | `None`, optional): When not `None`, then it is added as the namespace for the "no label" prefix (`:`) to the prefixes used with every query.
                Defaults to `None`.
        """
        self._prefixes = dict(SparqlUtils.default_sparql_prefixes)
        self.update_no_label_prefix(no_label_namespace)

    def _prefixes_string(self) -> str:
        """Creates the prefix string code for SPARQL from the internal prefix list.

        Returns:
            `str`: SPARQL code for the known prefixes.
        """
        return '\n'.join([f'PREFIX {k} <{v}>' for k, v in self._prefixes.items()])

    def update_no_label_prefix(self, no_label_namespace:str | None = None):
        """Updates the "no label" prefix (`:`), either changing its value or removing it.

        Args:
            no_label_prefix (`str` | `None`, optional): The namespace to use for the "no label" prefix (`:`).
                When `None`, then the "no label" prefix is removed.
                Defaults to `None`.
        """
        if no_label_namespace is None:
            self._prefixes.pop(':', None)
        else:
            self._prefixes[':'] = no_label_namespace
        # We assume that prefixes won't change that often, so instead of generating the prefix code every time we cache it.
        self._prefix_code = self._prefixes_string()

    def sparql_string(self, code:str) -> str:
        """Extend the provided SPARQL code with the things that the SparqlUtils object manages, like a certain set of prefixes.

        Args:
            code (`str`): The SPARQL code to extend.

        Returns:
            `str`: The extended SPARQL code.
        """
        return self._prefix_code + '\n\n' + code



#region --- SparqlQueryOlive -------------------------------------------------
# Class to execute SPARQL commands through the Olive MSC.
#-----------------------------------------------------------------------------

class SparqlQueryOlive(SparqlUtils):
    """Utility class to execute SPARQL queries (not SPARQL update) through a microservice on an Olive MSC easier.
    """

    def __init__(self, olive_endpoint:str, microservice:str, operation_id:str, repository:str, no_label_namespace:str | None = None):
        """Create a new object to execute SPARQL queries through an Olive MSC microservice.

        Args:
            olive_endpoint (`str`): The endpoint (URL) where the Olive MSC REST API can be reached.
            microservice (`str`): The name or identifier of the microservice configuration.
            operation_id (`str`): The identifier of the operation that executes a SPARQL query.
            repository (`str`): The name of the repository that stores the RDF data.
            no_label_prefix (`str` | `None`, optional): When not `None`, then it is added as the namespace for the "no label" prefix (`:`) to the prefixes used with every query.
                Defaults to `None`.

        Raises:
            TypeError: Raised when a mandatory parameter is missing.
        """
        # Catch incompatible types.
        if not isinstance(olive_endpoint, str):
            raise TypeError('The `olive_endpoint` parameter must be a text (of type `str`).')
        if not isinstance(microservice, str):
            raise TypeError('The `microservice` parameter must be a text (of type `str`).')
        if not isinstance(operation_id, str):
            raise TypeError('The `operation_id` parameter must be a text (of type `str`).')
        if not isinstance(repository, str):
            raise TypeError('The `repository` parameter must be a text (of type `str`).')
        # Set the internal variables of the object.
        self.msc = olive.OliveMsc(olive_endpoint)
        self.microservice = microservice
        self.exec_op = operation_id
        self.repository = repository
        # The rest is handled by the superclass.
        super().__init__(no_label_namespace)

    def olive_input_object(self, query:str) -> dict[str, str]:
        """Simple helper function that creates the input object sent to the Olive MSC for executing the SPARQL query operation.

        Args:
            query (`str`): The SPARQL query to execute.
                The prefixes set in the object are prepended to the actual query.

        Returns:
            `dict[str, str]`: Object to be sent to the Olive MSC for executing the SPARQL query operation.
        """
        return {
            'repositoryID': self.repository,
            'sparqlQuery': self.sparql_string(query)
        }

    def execute_query(self, query:str) -> dict[str, dict[str, list[str | dict[str, dict[str, str]]]]]:
        """Executes the provided SPARQL query through the Olive MSC.

        Args:
            query (`str`): The SPARQL query to execute.
                The prefixes set in the object are prepended to the actual query.

        Returns:
            `dict[str, dict[str, list[str | dict[str, dict[str, str]]]]]`: The results from the query.
                For details see [SPARQL 1.1 Query Results JSON Format](https://www.w3.org/TR/sparql11-results-json/) specification.
                It's a dictionary that contains a `'head'` and a `'results'` key.
                Under `'head'` is a dict with a `'vars'` key that holds a `list` with all the variable names.
                Under `'results'` is a dict with a `'bindings'` key that holds a `list` of dictionaries with details on the variable bindings.
                The name of the variable is used as the key and the value is a dictionary with details on the bound `'value'` and it's `'type'` (`'uri'`, `'literal'` or `'bnode'`).
                Bindings of type `'literal'` can optionally contain their `'datatype'` or language tag via `'xml:lang'`.
                Note that variables can be optional in the result of a SPARQL query and thus do not necessarily appear in every result binding.

        Example for returned value in JSON format:
        ```
            {
                "head": {
                    "vars": ["Actor", "Object", "Amount"]
                },
                "results": {
                    "bindings": [{
                            "Actor": {
                                "type": "uri",
                                "value": "http://example.org/cebm/adoxx-rdf/#Actor-14210-Tomato_Farmer"
                            },
                            "Object": {
                                "type": "literal",
                                "value": "Tomato Stems"
                            },
                            "Amount": {
                                "datatype": "http://www.w3.org/2001/XMLSchema#decimal",
                                "type": "literal",
                                "value": "0"
                            }
                        }, {
                            "Actor": {
                                "type": "uri",
                                "value": "http://example.org/cebm/adoxx-rdf/#Actor-14111-Supplier_Chemicals"
                            },
                            "Object": {
                                "type": "literal",
                                "value": "Cellulose (unbleached softwood) "
                            },
                            "Amount": {
                                "datatype": "http://www.w3.org/2001/XMLSchema#decimal",
                                "type": "literal",
                                "value": "450"
                            }
                        }, {
                            "Actor": {
                                "type": "uri",
                                "value": "http://example.org/cebm/adoxx-rdf/#Actor-14111-Supplier_Chemicals"
                            },
                            "Object": {
                                "type": "literal",
                                "value": "Cellulose (bleached softwood)"
                            },
                            "Amount": {
                                "datatype": "http://www.w3.org/2001/XMLSchema#decimal",
                                "type": "literal",
                                "value": "3450"
                            }
                        }
                    ]
                }
            }
        ```
        """
        return self.msc.olive_call_operation(self.microservice, self.exec_op, self.olive_input_object(query))



#region --- SparqlBindingsTransformer ----------------------------------------
# Class collecting functions to transform SPARQL bindings to other data structures.
#-----------------------------------------------------------------------------

class SparqlResultsTransformer(ABC):
    """Abstract class for transformers from SPARQL bindings (as described in [SPARQL 1.1 Query Results JSON Format](https://www.w3.org/TR/sparql11-results-json/)) to a different data structure.
    """

    def __init__(self, derive_missing_label:bool = True): #TODO strict_datatypes:bool = False):
        """This class is abstract to provide some common ground for such transformers. Use one of the concrete subclasses instead.

        Args:
            derive_missing_label (`bool`, optional): Whether to try and derive a human readable label for IRI resources when an explicit one is not available.
                See documentation of `SparqlBindingsTransformer.interpret_binding_value` for details.
                Defaults to `True`.
        """
        self.derive_missing_label = derive_missing_label
        self.strict_datatypes = False
        super().__init__()

    def interpret_binding_value(self, query_solution:dict[str, dict[str, str]], variable_name:str) -> Any:
        """Returns a Python value for a variable binding in a query solution.

        This is necessary, because the value in the results from a query solution is always a string, with additional metadata.
        To make processing the results easier this method transforms those values into a fitting Python type:
        * IRI resources (`type == 'uri'`) are transformed into an `RdfIriResource` object.
        * All others are treated as literals and are transformed into the corresponding built-in types, like `int`, `float` or `str`.

        For IRI resources this method also tries to determine a human readable label.
        The query solution can contain a binding for a special variable with a name like `_label_[variable_name]` to provide an explicit label for the IRI resource of [variable_name].
        If one is not available and self.derive_missing_label is true, then a human readable label is derived (when possible) by taking the fragment from the URL (part after the number sign `#`).

        Args:
            query_solution (`dict[str, dict[str, str]]`): The dictionary describing a single query solution containing all the variable bindings.
                Each key is a variable name and the bound value is detailed through a dictionary.
                The inner dictionary MUST contain a `'type'` and a `'value'` key.
            variable_name (`str`): The name of the variable for which to get the value.

        Raises:
            TypeError: Raised when any of the parameters is of a wrong type.

        Returns:
            `Any`: A Python value closely resembling the value from the binding.
        """
        # Assumes that 'type' is only either 'uri' or 'literal'.
        #TODO according to [SPARQL 1.1 Query Results JSON Format](https://www.w3.org/TR/sparql11-results-json/) specification the type can also be bnode to indicate a blank node. That should be handled here as well.
        binding_value = query_solution[variable_name]
        label_variable_name = f'_label_{variable_name}'
        label = query_solution[label_variable_name].get('value') if label_variable_name in query_solution else None
        type_ = binding_value.get('type')
        value_ = binding_value.get('value')
        if not isinstance(value_, str):
            raise TypeError(f'The `binding["{variable_name}"].value` parameter must be a text (of type `str`).')
        if type_ == 'uri':
            return RdfIriResource(value_, label = label if label is not None else self.derive_missing_label)
        elif self.strict_datatypes:
            # We have to manually transform based on what is specified as the 'datatype'.
            #datatype = binding_value.get('datatype', None)
            #TODO the [DataType Enum](https://github.com/tefra/xsdata/blob/main/xsdata/models/enums.py) from xsdata might be useful to help with the transformation.
            pass
        else:
            # Let the AST module evaluate it for us.
            # This raises an exception for example when value is just a string as those are not escaped, e.g. "Tire" instead of "'Tire'".
            try:
                return ast.literal_eval(value_)
            except Exception:
                return value_

    @abstractmethod
    def transform(self, query_results:dict[str, dict[str, list]], *args, **kwargs) -> Any:
        """Abstract method to transform SPARQL bindings to a different data structure.

        This should be implemented by the concrete classes.

        Args:
            query_results (`dict[str, dict[str, list]]`): The `dict` with the SPARQL query results.
                This should be the structure as described in [SPARQL 1.1 Query Results JSON Format](https://www.w3.org/TR/sparql11-results-json/) specification, for example as returned by `SparqlQueryOlive.execute_query`.

        Returns:
            `Any`: The new data structure.
        """
        pass



class SparqlResultsToWideDict(SparqlResultsTransformer):
    """Transformer class to transform SPARQL results to a two dimensional dictionary.

    The structure of the SPARQL results should be similar to long format data.
    The structure of the two dimensional dictionary is similar to wide format data.
    """

    def __init__(self, derive_missing_label:bool = True): #TODO strict_datatypes:bool = False):
        """Create a new transformer from SPARQL results to a two dimensional dictionary: `dict[str, dict[str, Any]]`.

        The structure of the SPARQL results should be similar to long format data.
        The structure of the two dimensional dictionary is similar to wide format data.

        For details on the transformed value see the `transform` method.

        Args:
            derive_missing_label (`bool`, optional): Used to try and derive a human readable label for IRI resources when an explicit one is not available.
                See documentation of `SparqlBindingsTransformer.interpret_binding_value` for details.
                Defaults to `True`.
        """
        super().__init__(derive_missing_label)

    @override
    def transform(self, query_results:dict[str, dict[str, list]], group_variable_name:str, property_variable_name:str, value_variable_name:str) -> dict[str, dict[str, Any]]:
        """Transforms the provided query results (should be similar to long format data) into a two dimensional dictionary similar to wide format data.

        * The first keys represent values for one aspect for the data to group by (in table terms: row or column).
        * The second keys represent values for another aspect for the data (in table terms: column or row).
        * The value is the data for the intersection of both aspects (in table terms: cell), which can be one or several values.

        One difference to normal tables is that there can be more than one value at the intersection of the two aspects, which is then provided as a list.
        Also because the values of both aspects are used as keys in a dictionary they are coerced into string values.

        For example, when executing a SPARQL query: `SELECT ?Subject ?Property ?Object WHERE { ?Subject ?Property ?Object . }` the first aspect could be `'Subject'`, the second aspect could be `'Property'` and the value would be for `'Object'`.
        This way the first keys would be all subjects from the query results, the second keys the known properties for the subject and the value would be the object(s) for the property of the subject.
        In this example `group_variable_name` should be `'Subject'`, `property_variable_name` should be `'Property'` and `value_variable_name` should be `'Object'`.
        The result could then look like:
        ```
            {
                "http://example.org/cebm/adoxx-rdf/model/#e3-Value_Model-e3-Value_ICP__01_-_Copy_1": {
                    "http://www.w3.org/1999/02/22-rdf-syntax-ns#type": "http://example.org/cebm#BusinessModel",
                    "http://www.w3.org/2000/01/rdf-schema#label": "e3-Value_ICP__01 - Copy",
                    "http://example.org/cebm#hasGeographicContext": "http://example.org/cebm/adoxx-rdf/model/#Slovenia",
                    "http://example.org/cebm#hasPerformanceIndicator": [
                        "http://example.org/cebm/adoxx-rdf/model/#ICP__01_-_Copy_1_pi1",
                        "http://example.org/cebm/adoxx-rdf/model/#ICP__01_-_Copy_1_pi2"
                    ],
                    "http://example.org/cebm#hasSector": "http://example.org/cebm/adoxx-rdf/model/#Farming",
                    "http://example.org/cebm#hasName": "e3-Value_ICP__01 - Copy",
                    "https://www.adoxx.org/mm#a_Name": "e3-Value_ICP__01 - Copy",
                },
                "http://example.org/cebm/adoxx-rdf/model/#e3-Value_Model-Agnostic_Example_-_e3V": {
                    "http://www.w3.org/1999/02/22-rdf-syntax-ns#type": "http://example.org/cebm#BusinessModel",
                    "http://www.w3.org/2000/01/rdf-schema#label": "Agnostic Example - e3V",
                    "http://example.org/cebm#hasGeographicContext": "http://example.org/cebm/adoxx-rdf/model/#Germany",
                    "http://example.org/cebm#hasPerformanceIndicator": [
                        "http://example.org/cebm/adoxx-rdf/model/#Agnostic_Example_pi1",
                        "http://example.org/cebm/adoxx-rdf/model/#Agnostic_Example_pi2",
                        "http://example.org/cebm/adoxx-rdf/model/#Agnostic_Example_pi3"
                    ],
                    "http://example.org/cebm#hasSector": "http://example.org/cebm/adoxx-rdf/model/#Farming",
                    "http://example.org/cebm#hasName": "Agnostic Example - e3V",
                    "https://www.adoxx.org/mm#a_Name": "Agnostic Example - e3V",
                }
            }
        ```

        Args:
            query_results (`dict[str, dict[str, list]]`): The `dict` with the SPARQL query results.
                This should be the structure as described in [SPARQL 1.1 Query Results JSON Format](https://www.w3.org/TR/sparql11-results-json/) specification, for example as returned by `SparqlQueryOlive.execute_query`.
                The value structure should be similar to long format data.
                For example the structure returned from `SparqlQueryOlive.execute_query`.
            group_variable_name (`str`): Name of the variable whose value bindings to use for the keys for the outer dictionary.
                These are grouped together in that they only appear once as keys of the outer dictionary.
            property_variable_name (`str`): Name of the variable whose value bindings to use for the keys for the inner dictionary.
                These can be considered properties for the for the keys of the outer dictionary.
            value_variable_name (`str`): Name of the variable whose value bindings to use for the the value(s).

        Raises:
            ValueError: Raised when the provided `query_results` is missing necessary values.

        Returns:
            `dict[str, dict[str, Any]]`: A two dimensional dictionary, providing the data similar to wide format data.
                A combination of the outer key and inner key can have more than one value, in which case the value will be a list.
        """
        variables:list[str] | None = query_results.get('head', {}).get('vars', None)
        if variables is None:
            raise ValueError("Failed to determine the result variables (query_results['head']['vars']) from the provided input.")
        bindings:list[dict[str, dict[str, str]]] | None = query_results.get('results', {}).get('bindings', None)
        if bindings is None:
            raise ValueError("Failed to determine the result bindings (query_results['results']['bindings']) from the provided input.")
        result = {}
        for bind in bindings:
            id_val = self.interpret_binding_value(bind, group_variable_name)
            if not isinstance(id_val, str):
                id_val = str(id_val)
            # Initialize with an empty dictionary if it is missing, so that we can be sure that it exists when we need it.
            if id_val not in result:
                result[id_val] = {}
            id_obj = result[id_val] # We make use of getting the reference here.
            property_val = self.interpret_binding_value(bind, property_variable_name)
            if not isinstance(property_val, str):
                property_val = str(property_val)
            value_val = self.interpret_binding_value(bind, value_variable_name)
            # If the property is already set for the object, then we transform it to a list.
            if property_val in id_obj:
                if isinstance(id_obj[property_val], list):
                    id_obj[property_val].append(value_val)
                else:
                    id_obj[property_val] = [id_obj[property_val], value_val]
            else:
                id_obj[property_val] = value_val
        return result



class SparqlResultsToWideDataFrame(SparqlResultsTransformer):
    """Transformer class to transform SPARQL results to a wide format `pandas.DataFrame`.

    The structure of the SPARQL results should be similar to long format data.

    See [Plotly wide-form documentation](https://plotly.com/python/wide-form/) for more information on wide format data.
    """

    def __init__(self, derive_missing_label:bool = True): #TODO strict_datatypes:bool = False):
        """Create a new transformer from SPARQL results to a wide format `pandas.DataFrame`.

        The structure of the SPARQL results should be similar to long format data.

        For details on the transformed value see the `transform` method.

        See [Plotly wide-form documentation](https://plotly.com/python/wide-form/) for more information on wide format data.

        Args:
            derive_missing_label (`bool`, optional): Used to try and derive a human readable label for IRI resources when an explicit one is not available.
                See documentation of `SparqlBindingsTransformer.interpret_binding_value` for details.
                Defaults to `True`.
        """
        super().__init__(derive_missing_label)

    @override
    def transform(self, query_results:dict[str, dict[str, list]], row_variable_name:str, column_variable_name:str, value_variable_name:str, missing_value:Any = None, row_values_as_index:bool = False, initialized:dict[str, dict[str, Any]] | None = None, extend_initialized:bool = True) -> pd.DataFrame:
        """Transforms the provided query results (should be similar to long format data) into a wide format `pandas.DataFrame`.

        A wide format data frame spreads one aspect along the rows, another aspect along the columns and the cells containing the values for their intersection.

        See [Plotly wide-form documentation](https://plotly.com/python/wide-form/) for more information on wide format data.

        For example using a SPARQL query that retrieves performance indicator values for various strategies and dimensions of a business model:
        ```
            SELECT ?Business_model ?Strategy ?Dimension ?Value
            WHERE {
                VALUES ?Business_model { <http://example.org/cebm/adoxx-rdf/model/#e3-Value_Model-e3-Value_ICP__01_-_Copy_1> }
                ?Business_model cebm:hasPerformanceIndicator ?pi .
                ?pi cebm:appliesStrategy ?Strategy .
                ?pi cebm:hasDimension ?Dimension .
                ?pi cebm:performanceValue ?Value .
            }
        ```

        When transforming the result with the parameters `row_variable_name = 'Strategy'`, `column_variable_name = 'Dimension'`, `value_variable_name = 'Value'`, `missing_value = npy.nan`, `initialized = {k1: {k2: npy.nan for k2 in IRIS_DIMENSION.values()} for k1 in IRIS_STRATEGY.values()}` (initialize values for the known strategies and dimensions with `NaN`) and leaving the other parameters with their default values would result in the following `pandas.DataFrame`:
        ```pandas.DataFrame:
                    Strategy  Environmental  Economic  Social
            0         Reduce            NaN       NaN     NaN
            1          Reuse            NaN       5.0     NaN
            2         Repair            NaN       NaN     NaN
            3      Refurbish            NaN       NaN     NaN
            4  Remanufacture            NaN       NaN     NaN
            5      Repurpose            3.0       6.0     NaN
            6        Recycle            NaN       NaN     NaN
        ```

        Args:
            query_results (`dict[str, dict[str, list]]`): The `dict` with the SPARQL query results.
                This should be the structure as described in [SPARQL 1.1 Query Results JSON Format](https://www.w3.org/TR/sparql11-results-json/) specification, for example as returned by `SparqlQueryOlive.execute_query`.
                The value structure should be similar to long format data.
            row_variable_name (`str`): Name of the variable whose value bindings to use for the rows.
            column_variable_name (`str`): Name of the variable whose value bindings to use for the columns.
            value_variable_name (`str`): Name of the variable whose value bindings to use for the the value in the cells.
            missing_value (`Any`, optional): Value to use for row / column combinations that do not have am explicit value.
                Defaults to `None`.
            row_values_as_index (`bool`, optional): When `True` then the values from `row_variable_name` will be used as the index and not appear as its own column.
                Otherwise the values from `row_variable_name` will be put in its own column and the index will be numbers starting from `0`.
                It is easier to use a wide format data frame with Dash or transform a data frame to long format when this is `False`.
                Defaults to `False`.
            initialized (`dict[str, dict[str, Any]]` | `None`, optional): Allows to specify initial data to use for the wide format data frame.
                This can be useful when you expect the query results to not contain values for all row / column combinations.
                It should be a two dimensional dictionary where the first key specifies the row value, the second key the column value, and the value is the value.
                Defaults to `None`.
            extend_initialized (`bool`, optional): When `True`, then additional rows and columns will be added to the provided initialized values should they appear in the query results.
                Otherwise only rows and columns that are already present in `initialized` will have their values set and any other bindings will be ignored.
                Can be useful to filter the results only for specific values.
                When `initialized` is `None` then this is always considered `True`.
                Defaults to `True`.

        Raises:
            ValueError: Raised when the provided `query_results` is missing necessary values.

        Returns:
            `pd.DataFrame`: A `pandas.DataFrame` object with the data in wide format.
        """
        variables:list[str] | None = query_results.get('head', {}).get('vars', None)
        if variables is None:
            raise ValueError("Failed to determine the result variables (query_results['head']['vars']) from the provided input.")
        bindings:list[dict[str, dict[str, str]]] | None = query_results.get('results', {}).get('bindings', None)
        if bindings is None:
            raise ValueError("Failed to determine the result bindings (query_results['results']['bindings']) from the provided input.")
        # Build a data structure that is easier to handle for us.
        extend_initialized = True if initialized is None else extend_initialized
        restructured = {} if initialized is None else copy.deepcopy(initialized)
        # Add all the column names that might already be in initialized.
        # Note: set is apparently not ordered and the "workaround" is to just use keys in a dict, as dict is ordered.
        all_column_values = {v2: None for v in restructured.values() for v2 in v.keys()}
        # Extend restructured with the information from the bindings.
        for bind in bindings:
            row_val = self.interpret_binding_value(bind, row_variable_name)
            column_val = self.interpret_binding_value(bind, column_variable_name)
            value_val = self.interpret_binding_value(bind, value_variable_name)
            all_column_values[column_val] = None
            if row_val in restructured and (extend_initialized or (column_val in restructured[row_val])):
                restructured[row_val][column_val] = value_val
            elif extend_initialized:
                restructured[row_val] = {column_val: value_val}
        # Now build a two dimensional list of the values.
        df_values = []
        for row_val in restructured.keys():
            df_inner_list = []
            if not row_values_as_index:
                df_inner_list.append(row_val)
            for column_val in all_column_values.keys():
                df_inner_list.append(restructured.get(row_val, {}).get(column_val, missing_value))
            df_values.append(df_inner_list)
        # And finally we get to create the data frame.
        return pd.DataFrame(df_values,
            index = list(restructured.keys()) if row_values_as_index else range(0, len(restructured)),
            columns = list(all_column_values.keys()) if row_values_as_index else [row_variable_name, *all_column_values.keys()])



class SparqlResultsToDataFrame(SparqlResultsTransformer):
    """Transformer class to transform SPARQL results to a `pandas.DataFrame`.

    The data is kept in the (wide or long) format that the SPARQL results are in.
    Typically this would be long format. To transform specifically to a wide format `pandas.DataFrame` use the class `SparqlResultsToWideDataFrame`.
    """

    def __init__(self, derive_missing_label:bool = True): #TODO strict_datatypes:bool = False):
        """Create a new transformer from SPARQL results to a `pandas.DataFrame`.

        For details on the transformed value see the `transform` method.

        Args:
            derive_missing_label (`bool`, optional): Used to try and derive a human readable label for IRI resources when an explicit one is not available.
                See documentation of `SparqlBindingsTransformer.interpret_binding_value` for details.
                Defaults to `True`.
        """
        super().__init__(derive_missing_label)

    @override
    def transform(self, query_results:dict[str, dict[str, list]]) -> pd.DataFrame:
        """Transforms the provided query results (should be similar to long format data) into a wide format `pandas.DataFrame`.

        The data is kept in the (wide or long) format that the SPARQL results are in.
        Variable names are added as columns unless they start with an underscore `_` (which seems to be an informal practice in SPARQL)

        If the resulting `pandas.DataFrame` does not have an 'id' column, then one is added containing the index of every row.
        An attribute 'column_display_names' (`dict[str, str]`) is also added which provides for each column id (key) a name (value) to display based on the variable names from the query results.

        Args:
            query_results (`dict[str, dict[str, list]]`): The `dict` with the SPARQL query results.
                This should be the structure as described in [SPARQL 1.1 Query Results JSON Format](https://www.w3.org/TR/sparql11-results-json/) specification, for example as returned by `SparqlQueryOlive.execute_query`.

        Raises:
            ValueError: Raised when the provided `query_results` is missing necessary values.

        Returns:
            `pd.DataFrame`: A `pandas.DataFrame` object with the data and an additional `column_display_names` attribute.
        """
        # Get the relevant inputs.
        variables:list[str] | None = query_results.get('head', {}).get('vars', None)
        if variables is None:
            raise ValueError("Failed to determine the result variables (query_results['head']['vars']) from the provided input.")
        # Filter out all variables that start with an underscore.
        variables = [var for var in variables if not var.startswith('_')]
        bindings:list[dict[str, dict[str, str]]] | None = query_results.get('results', {}).get('bindings', None)
        if bindings is None:
            raise ValueError("Failed to determine the result bindings (query_results['results']['bindings']) from the provided input.")
        # Build the long-form data for the data frame.
        long_form_data = {v: [] for v in variables}
        for bind in bindings:
            for varname in variables:
                # Capture "optional variable" cases.
                if varname not in bind:
                    long_form_data[varname].append(None)
                    continue
                # Add the value in the correct type and add an optional label if one is available.
                value = self.interpret_binding_value(bind, varname)
                long_form_data[varname].append(value)
        # Create the data frame object
        df = pd.DataFrame(long_form_data)
        # Add the id column to the DataFrame, so that we can access rows via ID.
        if 'id' not in df:
            df['id'] = df.index
        # Extend the data frame object with additional attributes useful to us.
        # We have to tell the dataframe about custom attributes, otherwise Pandas complains:
        # https://pandas.pydata.org/pandas-docs/stable/development/extending.html#define-original-properties
        df._metadata.append('column_display_names')
        # Add the 'column_display_names' attribute.
        column_display_names:dict[str, str] = {}
        for col in df.columns:
            display_name = col.replace('_', ' ')
            column_display_names[col] = display_name
        setattr(df, 'column_display_names', column_display_names)
        return df



#region --- RdfIriResource ---------------------------------------------------
# Class to represent IRI resources in RDF.
# Primarily used to distinguish between literals (non-IRI resources) and referents (resource denoted by IRI).
#-----------------------------------------------------------------------------

class RdfIriResource(str):
    """Class used primarily to differentiate between normal string values and explicitly RDF IRI resources.

    From [RDF 1.1 Concepts and Abstract Syntax](https://www.w3.org/TR/2014/REC-rdf11-concepts-20140225/#resources-and-statements):
    > Any IRI or literal denotes something in the world (the "universe of discourse"). These things are called resources.
    > The resource denoted by an IRI is called its referent, and the resource denoted by a literal is called its literal value.

    #TODO currently only URLs are supported as valid IRIs.

    The object as a value itself represents the full IRI (internal string value is the IRI), which can also be accessed explicitly via the `full_iri` property.
    This is necessary to allow comparison etc. to work correctly using the IRI.
    The object also provides other properties to make working with IRI resources easier.
    """

    @classmethod
    def valid_url(cls, s:str) -> bool:
        """Checks if the provided string is a valid URL.
        A string is considered a valid URL if it follows the URL syntax specification and has a non-empty scheme and network location.

        For further details see [Python's `urllib.parse.urlparse` function](https://docs.python.org/3/library/urllib.parse.html#urllib.parse.urlparse)

        Args:
            s (`str`): The string to check.

        Returns:
            `bool`: `True` when the string is a valid URL, otherwise `False`.
        """
        try:
            u = urlparse(s)
            return all([u.scheme, u.netloc])
        except Exception:
            return False

    @classmethod
    def cast_if_valid(cls, value:str, coerce_str:bool = True, **kwargs) -> Self | str:
        """Returns the provided value as an `RdfIriResource` if possible. Otherwise returns the value itself.

        If the passed value is already is an `RdfIriResource`, then that object is returned.
        Otherwise if it is a valid value for an `RdfIriResource`, then a new `RdfIriResource` object is created and returned.
        Otherwise if `coerce_str` is true, then the value is returned as a string.
        Otherwise the same value is returned that was provided.

        Args:
            value (`str`): The value to get as an `RdfIriResource` if possible.
            coerce_str (`bool`): When true, then the returned value will always be of type `RdfIriResource` or `str`.
                Otherwise the returned value will keep its original type, whatever it was.
                Defaults to `True`.
            **kwargs: Any other keyword arguments are passed construction of a new `RdfIriResource` object.

        Returns:
            `RdfIriResource` | `str`: The value as an RdfIriResource when it is valid for one. Otherwise the value as it was.
        """
        if isinstance(value, RdfIriResource):
            return value
        elif RdfIriResource.valid_url(value):
            return RdfIriResource(value, **kwargs)
        elif coerce_str:
            return str(value)
        else:
            return value

    def __new__(cls, value:str, namespace:str | bool | None = True, label:str | bool | None = True):
        """Create a new `RdfIriResource`.

        #TODO currently only URLs are supported as valid IRIs.

        Args:
            value (`str`): The IRI of the resource.
            namespace (`str` | `bool` | `None`, optional): The namespace part of the IRI.
                When either a string or the value `None` is provided then they are used directly.
                `None` should be used to explicitly state that there is no namespace.
                If the boolean type value `True` is provided, then the function tries to guess the namespace based on the first occurrence of the `#` character.
                If one is not found (or the boolean type value `False` has been provided) then namespace will be `None`.
                Defaults to `True`.
            label (`str` | `bool` | `None`, optional): An optional human readable label for the IRI resource.
                When either a string or the value `None` is provided then they are used directly.
                `None` should be used to explicitly state that there is no label.
                If the boolean type value `True` is provided, then the method will try to derive a label based on the part of `value` after the namespace.
                This does some modifications, like replacing underscores `_` with spaces ` ` for a human readable label.
                If `label` is boolean type `False` or the `RdfIriResource` does not have a namespace, then the label is assumed to be `None`.
                Defaults to `True`.

        Returns:
            `RdfIriResource`: A new `RdfIriResource` object with the internal string initialized to the provided `value`.
        """
        obj = super().__new__(cls, value)
        if isinstance(namespace, bool):
            number_sign = (value.find('#') + 1) if namespace else -1
            # The check is against > 0, because the search for a # adds 1.
            namespace = value[0:number_sign] if number_sign > 0 else None
        setattr(obj, '_namespace', namespace)
        short_name = value[len(namespace):] if isinstance(namespace, str) and value.startswith(namespace) else None
        if isinstance(label, bool):
            label = short_name.replace('_', ' ') if label and short_name else None
        setattr(obj, '_label', label)
        return obj

    @property
    def full_iri(self) -> str:
        """The object itself, being the full IRI. Read-only."""
        return self

    @property
    def namespace(self) -> str:
        """The namespace part of the IRI. Read-only."""
        # _namespace can be a string or None.
        namespace = getattr(self, '_namespace')
        return namespace if namespace else ''

    @property
    def label(self) -> str | None:
        """An optional label for the resource. Can be `None` if there is no label."""
        return getattr(self, '_label')

    @label.setter
    def label(self, value:str | None):
        setattr(self, '_label', value)



#region --- Helper functions -------------------------------------------------
# Additional functions to help with 
#-----------------------------------------------------------------------------

def dataframe_labels_for_values(df:pd.DataFrame, prepend_indicator:str = '') -> pd.DataFrame:
    """Returns a new `pandas.DataFrame` where the values have been replaced with their label if they have one.
    A value is considered to have a label when it has the an attribute `'label'` that is not None.
    Otherwise the value is kept as is.

    This is for example useful when the values are `RdfIriResource` and should be presented to a user.
    Note however that the returned data frame has normal `str` values instead of `RdfIriResource` values, so the IRIs are lost!

    This function does not replace the IRIs used as columns or row indexes.

    Args:
        df (`pd.DataFrame`): The `pandas.DataFrame` to clone and replace the values in.
        prepend_indicator (`str`, optional): A string to put before any label, for example to indicate that the value was replaced.
            This one is used "as is", so if there should be a space between the two make sure to add one!
            Defaults to `''`.

    Returns:
        `pd.DataFrame`: A new `pandas.DataFrame` where the values have been replaced with labels when possible.
    """
    return df.map(
            lambda val: f'{prepend_indicator}{val.label}' if hasattr(val, 'label') and val.label is not None else val,
            'ignore'
        )

def get_columns_definition(df:pd.DataFrame, template:dict = {}) -> list[dict]:
    """Gets a columns definition for a `dash_table.DataTable` from a `pandas.DataFrame`.

    When the `pandas.DataFarme` has an attribute `column_display_names`, then the names are used from there.
    The `column_display_names` attribute should be a dict where the keys are the identifiers of the columns and the values are the names for the columns.
    Otherwise the column names are used as specified in `df.columns`.
    The `'id'` column is skipped, since it has a specific meaning for a `dash_table.DataTable`.

    Args:
        df (`pd.DataFrame`): The `pandas.DataFrame` from where to generate the columns definition.
        template (`dict`, optional): A template object to use for each column definition.
            For example use `{'hideable': True}` to allow the user to hide every column.
            The keys `'id'` or `'name'` are ignored, as those are generated by the function.
            See the the [`dash_table.DataTable` reference](https://dash.plotly.com/datatable/reference) for possible properties.
            Defaults to `{}`.

    Returns:
        `list[dict]`: A columns definition for a `dash_table.DataTable`.
    """
    column_display_names = getattr(df, 'column_display_names', None)
    if isinstance(column_display_names, dict):
        return [{**template, 'id':k, 'name':v} for k, v in column_display_names.items() if k != 'id']
    else:
        return [{**template, 'id':col, 'name':col} for col in df.columns if col != 'id']
