
//region --- Generic callbacks -----------------------------------------------
// Generic functions that are used for certain callback situations.
//----------------------------------------------------------------------------

/**
 * Generic callback function that returns the object that is passed as a parameter.
 * 
 * Used for example to update a dcc.State like `#decide-dashboard-current-user-group.data`.
 * 
 * @param {*} obj The object to return.
 * @returns {*} The object passed as the parameter.
 */
function returnParameter(obj) {
  return obj;
}



/**
 * Generic function to get the HTML element descriptions for Plotly to show the information about a node.
 * 
 * It is assumed that the info is part of a ListGroup and that the node_data provides certain details.
 * 
 * @param {Object} nodeData The details about the node to create the info section from.
 * @param {string} [nodeData.iri] The IRI the node represents.
 *    It is used as the info for the node. If not available then the label is used instead.
 * @param {string} [nodeData.label] The label used of the node.
 *    It is used as the info for the node if iri is not available.
 *    The text "None" will be used when it is not available (falsy).
 * @returns {Object[]} The children to use for the info section to show information about the node.
 */
function getNodeDetailsSectionChildren(nodeData) {
  return [
    {
      'type': 'ListGroupItem',
      'props': {
        'children': (nodeData.iri) ? nodeData.iri : ((nodeData.label) ? nodeData.label : 'None'),
        'className': `${(nodeData.iri) ? 'node' : 'literal'} icq network-graph details output`,
        'color': (nodeData.iri) ? 'primary' : 'secondary'
      },
      'namespace': 'dash_bootstrap_components'
    }
  ];
}



/**
 * Generic function to get the HTML element descriptions for Plotly to show the information about an edge.
 * 
 * It is assumed that the info is part of a ListGroup and that the edge_data provides certain details.
 * 
 * @param {Object} edgeData The details about the edge to create the info section from.
 * @param {string} [edgeData.source_info] The basic information about the source of the edge.
 *    The text "None" will be used when it is not available (falsy).
 * @param {string} [edgeData.iri] The IRI the edge represents.
 *    It is used as the info for the edge. If not available then the label is used instead.
 * @param {string} [edgeData.label] The label used of the edge.
 *    It is used as the info for the edge if iri is not available.
 *    The text "None" will be used when it is not available (falsy).
 * @param {string} [edgeData.target_info] The basic information about the target of the edge.
 *    The text "None" will be used when it is not available (falsy).
 * @returns {Object[]} The children to use for the info section to show information about the edge.
 */
function getEdgeDetailsSectionChildren(edgeData) {
  return [
    {
      'type': 'ListGroupItem',
      'props': {
        'children': (edgeData.source_info) ? edgeData.source_info : 'None',
        'className': 'edge source icq network-graph details output',
        'color': 'secondary'
      },
      'namespace': 'dash_bootstrap_components'
    }, {
      'type': 'ListGroupItem',
      'props': {
        'children': (edgeData.iri) ? edgeData.iri : ((edgeData.label) ? edgeData.label : 'None'),
        'className': 'edge icq network-graph details output',
        'color': 'primary'
      },
      'namespace': 'dash_bootstrap_components'
    }, {
      'type': 'ListGroupItem',
      'props': {
        'children': (edgeData.target_info) ? edgeData.target_info : 'None',
        'className': 'edge target icq network-graph details output',
        'color': 'secondary'
      },
      'namespace': 'dash_bootstrap_components'
    }
  ];
}

//endregion ------------------------------------------------------------------



//region --- Specific callbacks ----------------------------------------------
// Functions that realize callbacks which are specific to a part.
// These can not be simply generalized, for example because of very specific
// input and / or output structures.
//----------------------------------------------------------------------------

/**
 * Changes the theme used on the site.
 * 
 * @param {boolean} switchToDark True when the dark theme should be used, otherwise false to use the light theme.
 * @returns Always window.dash_clientside.no_update since the change is directly made via JavaScript DOM manipulation.
 */
function switchTheme(switchToDark) {
  document.documentElement.setAttribute('data-bs-theme', switchToDark ? 'dark' : 'light');
  return window.dash_clientside.no_update;
}



/**
 * Callback function to handle changes to the active cell in the main table.
 * 
 * Updates the stored last-selection, the info section underneath the table and
 * enables or disables the "Show Details" button based on whether a valid IRI (URL) has been selected.
 * 
 * To make the tables more readable the IRIs are stored in the table's tooltip list instead of the cell.
 * 
 * @param {Object} activeCell Information about the active cell, for example when one is selected.
 * @param {number} activeCell.row The index of the row in the `derived_viewport_data` (not accessed here).
 * @param {number} activeCell.column The index of the column in the `derived_viewport_data` (not accessed here).
 * @param {number | string} activeCell.column_id The identifier of the column.
 *    Can be used to directly access data from most sources, like `data`, `derived_viewport_data`, `tooltip_data` etc.
 * @param {number | string | undefined} activeCell.row_id The identifier of the row.
 *    The table MUST be initialized with an 'id' column for `row_id` to have a value.
 *    Can be used to directly access data from some sources, like `data`, `tooltip_data` etc., but not `derived_viewport_data`!
 * @param {Object[]} tooltipData An array of objects with the entire tooltip data for the table.
 *    Each object represents one tooltips for row of data where the key is the column identifier (`column_id`) and
 *    the value is again an object with the tooltip details. The tooltip details always have `value`, but
 *    the keys `delay`, `duration` and `type` are optional.
 * @param {Object} currentInfoSection The object describing the current state of the HTML element.
 *    This is not the HTML element, but a JSON object description of it.
 * @returns {Array} The last selection made (string), the object description for the selection info under the table and
 *    whether the "Show Details" button should be disabled.
 *    Values for `#icq1-main-last-selection.data`, `#icq1-main-selection-info.children` and `icq1-main-selection-show-details.disabled`.
 */
function icq1MainTableSelection(activeCell, tooltipData, currentInfoSection) {
  if (activeCell) {
    selectionValue = tooltipData?.[activeCell?.row_id]?.[activeCell?.column_id]?.value;
    //TODO Currently this only checks if the selection value is a valid URL with a limited amount of schemes.
    isIri = false;
    try {
      new URL(selectionValue); // Tests whether the value is a valid URL.
      isIri = true;
    } catch (err) {
    }
    currentInfoSection.props.children = selectionValue;
    currentInfoSection.props.className = `${(isIri) ? 'node' : 'literal'} icq selection details output`;
    currentInfoSection.props.color = (isIri) ? 'primary' : 'secondary';
    return [selectionValue, currentInfoSection, !isIri];
  }
  throw window.dash_clientside.PreventUpdate;
}



/**
 * Callback function to handle changes to the active cell in the details table.
 * 
 * Updates the stored last-selection, the info section underneath the table and
 * enables or disables the "Show Details" button based on whether a valid IRI (URL) has been selected.
 * 
 * To make the tables more readable the IRIs are stored in the table's tooltip list instead of the cell.
 * 
 * @param {Object} activeCell Information about the active cell, for example when one is selected.
 * @param {number} activeCell.row The index of the row in the `derived_viewport_data` (not accessed here).
 * @param {number} activeCell.column The index of the column in the `derived_viewport_data` (not accessed here).
 * @param {number | string} activeCell.column_id The identifier of the column.
 *    Can be used to directly access data from most sources, like `data`, `derived_viewport_data`, `tooltip_data` etc.
 * @param {number | string | undefined} activeCell.row_id The identifier of the row.
 *    The table MUST be initialized with an 'id' column for `row_id` to have a value.
 *    Can be used to directly access data from some sources, like `data`, `tooltip_data` etc., but not `derived_viewport_data`!
 * @param {Object[]} tooltipData An array of objects with the entire tooltip data for the table.
 *    Each object represents one tooltips for row of data where the key is the column identifier (`column_id`) and
 *    the value is again an object with the tooltip details. The tooltip details always have `value`, but
 *    the keys `delay`, `duration` and `type` are optional.
 * @param {Object} currentInfoSection The object describing the current state of the HTML element.
 *    This is not the HTML element, but a JSON object description of it.
 * @returns {Array} The last selection made (string), the object description for the selection info under the table and
 *    whether the "Subject", "Property" and "Object" buttons should be disabled.
 *    Values for `#icq1-details-last-selection.data`, `#icq1-details-selection-info.children`, `icq1-details-selection-as-subject.disabled`,
 *    `icq1-details-selection-as-property.disabled` and `icq1-details-selection-as-object.disabled`.
 */
function icq1DetailsTableSelection(activeCell, tooltipData, currentInfoSection) {
  if (activeCell) {
    selectionValue = tooltipData?.[activeCell?.row_id]?.[activeCell?.column_id]?.value;
    //TODO Currently this only checks if the selection value is a valid URL with a limited amount of schemes.
    isIri = false;
    try {
      new URL(selectionValue); // Tests whether the value is a valid URL.
      isIri = true;
    } catch (err) {
    }
    currentInfoSection.props.children = selectionValue;
    currentInfoSection.props.className = `${(isIri) ? 'node' : 'literal'} icq selection details output`;
    currentInfoSection.props.color = (isIri) ? 'primary' : 'secondary';
    return [selectionValue, currentInfoSection, !isIri, !isIri, !isIri];
  }
  throw window.dash_clientside.PreventUpdate;
}




/**
 * Clears the dropdown list and its connected components.
 * Also disables the "Clear" button.
 * 
 * @param {number} clearButton The amount of times the `explore-search-clear` button has been selected.
 * @param {Object} currentInfoSection The object describing the current state of the HTML element.
 *    This is not the HTML element, but a JSON object description of it.
 * @returns {Array} An empty array, the value `null`, an empty string and the boolean value `true`.
 *    Values for `#explore-search.options`, `#explore-search.value`, `#explore-search-full-entry.data` and `#explore-search-clear.disabled`.
 */
function exploreClearOptions(clearButton, currentInfoSection) {
  if (clearButton) {
    currentInfoSection.props.children = 'Select an entry in the above dropdown to show its details.';
    currentInfoSection.props.className = 'explore selection details output';
    currentInfoSection.props.color = 'info';
    return [[], null, '', true, [], currentInfoSection];
  }
  throw window.dash_clientside.PreventUpdate;
}



/**
 * Updates the info section underneath the explore dropdown.
 * 
 * @param {string} selectionValue The value of the entry selected in the dropdown.
 * @param {Object} currentInfoSection The object describing the current state of the HTML element.
 *    This is not the HTML element, but a JSON object description of it.
 * @returns {Object} An object describing the new state for the information box.
 *    Value for `#explore-search-info.children`
 */
function exploreSearchSelection(selectionValue, currentInfoSection) {
  if (selectionValue) {
    currentInfoSection.props.children = selectionValue;
    currentInfoSection.props.className = 'node explore selection details output';
    currentInfoSection.props.color = 'primary';
    return currentInfoSection;
  }
  throw window.dash_clientside.PreventUpdate;
}



/**
 * Callback function to handle changes to the active cell in the details table.
 * 
 * Updates the stored last-selection, the info section underneath the table and
 * enables or disables the "Show Details" button based on whether a valid IRI (URL) has been selected.
 * 
 * To make the tables more readable the IRIs are stored in the table's tooltip list instead of the cell.
 * 
 * @param {Object} activeCell Information about the active cell, for example when one is selected.
 * @param {number} activeCell.row The index of the row in the `derived_viewport_data` (not accessed here).
 * @param {number} activeCell.column The index of the column in the `derived_viewport_data` (not accessed here).
 * @param {number | string} activeCell.column_id The identifier of the column.
 *    Can be used to directly access data from most sources, like `data`, `derived_viewport_data`, `tooltip_data` etc.
 * @param {number | string | undefined} activeCell.row_id The identifier of the row.
 *    The table MUST be initialized with an 'id' column for `row_id` to have a value.
 *    Can be used to directly access data from some sources, like `data`, `tooltip_data` etc., but not `derived_viewport_data`!
 * @param {Object[]} tooltipData An array of objects with the entire tooltip data for the table.
 *    Each object represents one tooltips for row of data where the key is the column identifier (`column_id`) and
 *    the value is again an object with the tooltip details. The tooltip details always have `value`, but
 *    the keys `delay`, `duration` and `type` are optional.
 * @param {Object} currentInfoSection The object describing the current state of the HTML element.
 *    This is not the HTML element, but a JSON object description of it.
 * @returns {Array} The last selection made (string), the object description for the selection info under the table and
 *    whether the "Subject", "Property" and "Object" buttons should be disabled.
 *    Values for `#icq1-details-last-selection.data`, `#icq1-details-selection-info.children`, `icq1-details-selection-as-subject.disabled`,
 *    `icq1-details-selection-as-property.disabled` and `icq1-details-selection-as-object.disabled`.
 */
function exploreDetailsTableSelection(activeCell, tooltipData, currentInfoSection) {
  if (activeCell) {
    selectionValue = tooltipData?.[activeCell?.row_id]?.[activeCell?.column_id]?.value;
    //TODO Currently this only checks if the selection value is a valid URL with a limited amount of schemes.
    isIri = false;
    try {
      new URL(selectionValue); // Tests whether the value is a valid URL.
      isIri = true;
    } catch (err) {
    }
    currentInfoSection.props.children = selectionValue;
    currentInfoSection.props.className = `${(isIri) ? 'node' : 'literal'} icq selection details output`;
    currentInfoSection.props.color = (isIri) ? 'primary' : 'secondary';
    return [selectionValue, currentInfoSection, !isIri, !isIri, !isIri];
  }
  throw window.dash_clientside.PreventUpdate;
}

//endregion ------------------------------------------------------------------



//region --- Clientside callback names ---------------------------------------
// Generic functions that are used for certain callback situations.
// These are not used with their name on the Dash side, instead 
//----------------------------------------------------------------------------

/**
 * Assign the specific functions to the object so that they can be accessed from Dash.
 */
window.dash_clientside = Object.assign({}, window.dash_clientside, {
  'clientside': {
    'switchTheme': switchTheme,
    'changeUserGroup': returnParameter,
    'icq1MainTableSelection': icq1MainTableSelection,
    'icq1DetailsTableSelection': icq1DetailsTableSelection,
    'icq3UpdateLastSelection': returnParameter,
    'icq3NodeUpdateDetailsSection': getNodeDetailsSectionChildren,
    'icq3EdgeUpdateDetailsSection': getEdgeDetailsSectionChildren,
    'exploreClearOptions': exploreClearOptions,
    'exploreSearchSelection': exploreSearchSelection,
    'exploreDetailsTableSelection': exploreDetailsTableSelection
  }
});

//endregion ------------------------------------------------------------------



//region --- Attaching events ------------------------------------------------
// Function and code to attach event listeners to elements.
// This is necessary because not all elements are available from the start.
//----------------------------------------------------------------------------

/**
 * Executes a `callback` function on a specific element that is retrieved via `selector`.
 * This is necessary when the element isn't yet available when the JavaScript is executed.
 * 
 * @param {string} selector A query selector (CSS) to get a specific HTML element.
 * @param {function} callback A function that takes one parameter: the HTML element object found.
 */
function executeOnElement(selector, callback) {
  // https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver
  new MutationObserver((mutations, observer) => {
    element = document.querySelector(selector);
    if (element) {
      // Detach the observer, unless we are running in "hot_reload" mode.
      // In "hot_reload" mode we have to most likely redo the the executed code.
      if (!window.dash_stores?.[0]?.getState()?.config?.hot_reload) {
        observer.disconnect();
      }
      callback(element);
    }
  }).observe(document.body, {
    childList: true,
    subtree: true
  });
}



/**
 * Attach event listener for "Enter" key to the input of explore-search.
 * Updates the explore-search-full-entry.data store with the value from the input.
 */
executeOnElement('#explore-search input', (element) => {
  // Set a unique Identifier for the event listener to not add it twice.
  const listenerId = '85fe84ef-6dc3-41b4-b0a3-1ddfefc6793a';
  if (!Array.isArray(element._customListeners) || !element._customListeners.includes(listenerId)) {
    if (Array.isArray(element._customListeners)) {
      element._customListeners.push(listenerId);
    } else {
      element._customListeners = [listenerId];
    }

    // Add the event listener.
    console.log(`Adding event listener '${listenerId}'.`);
    element.addEventListener('keydown', function(event) {
      if (event.key === 'Enter') {
        window.dash_clientside.set_props('explore-search-full-entry', {'data': event.target.value});
      }
    });
  }
});

//endregion ------------------------------------------------------------------
