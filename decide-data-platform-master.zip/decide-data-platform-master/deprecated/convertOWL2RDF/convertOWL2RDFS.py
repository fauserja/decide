
from rdflib import Graph, RDF, RDFS, OWL
import requests

def convert_owl_to_rdfs(input_file: str, output_file: str, input_format="turtle", output_format="turtle"):
    g = Graph()
    g.parse(input_file, format=input_format)

    rdfs_graph = Graph()

    for s, p, o in g:
        # Convert OWL class to RDFS class
        if p == RDF.type and o == OWL.Class:
            rdfs_graph.add((s, RDF.type, RDFS.Class))

        # Convert OWL properties to RDF properties
        elif p == RDF.type and o in (OWL.ObjectProperty, OWL.DatatypeProperty):
            rdfs_graph.add((s, RDF.type, RDF.Property))

        # Skip owl:Thing in domain/range
        elif p in (RDFS.domain, RDFS.range) and o == OWL.Thing:
            continue

        # Keep RDFS-relevant properties
        elif p in (RDFS.subClassOf, RDFS.domain, RDFS.range, RDFS.label, RDFS.comment):
            rdfs_graph.add((s, p, o))

        # Keep rdf:type statements not related to OWL constructs
        elif p == RDF.type and o not in (OWL.Class, OWL.ObjectProperty, OWL.DatatypeProperty, OWL.Ontology):
            rdfs_graph.add((s, p, o))

        # Skip owl:Ontology and other OWL axioms
        # All others are ignored unless explicitly handled

    rdfs_graph.serialize(destination=output_file, format=output_format)
    print(f"✅ Converted OWL to RDFS. Output saved to {output_file}")

def delete_repository(repo_id):
    url = f"http://localhost:7200/rest/repositories/{repo_id}"
    response = requests.get(url)
    if response.status_code == 200:
        # Repository exists, proceed with deletion
        response = requests.delete(url)
        if response.status_code == 200:
            print(f"✅ Repository '{repo_id}' deleted.")
        else:
            print(f"❌ Failed to delete repository '{repo_id}': {response.status_code} {response.text}")
    elif response.status_code == 404:
        print(f"ℹ️ Repository '{repo_id}' does not exist. Skipping deletion.")
    else:
        print(f"❌ Could not check repository status: {response.status_code} {response.text}")

def create_repository_from_ttl(config_path: str, repo_id: str):
    url = "http://localhost:7200/rest/repositories"
    with open(config_path, 'r', encoding='utf-8') as f:
        config_data = f.read().replace('<REPO_NAME>', repo_id)
    files = {
        'config': ('config.ttl', config_data)
    }

    response = requests.post(url, files=files)

    if response.status_code == 201:
        print("✅ Repository created successfully.")
    else:
        print(f"❌ Failed to create repository: {response.status_code}")
        print(response.text)

def count_classes_in_default_ns(repo_id: str, default_ns: str):
    url = f"http://localhost:7200/repositories/{repo_id}"
    query = f"""
 PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
 SELECT (COUNT(?class) AS ?count)
 WHERE {{
      ?class a rdfs:Class .
 }}  
    """
    headers = {"Accept": "application/sparql-results+json"}
    response = requests.post(url, data={"query": query}, headers=headers)
    if response.status_code == 200:
        result = response.json()
        count = result["results"]["bindings"][0]["count"]["value"]
        print(f"📊 Number of classes in default namespace: {count}")
    else:
        print(f"❌ Failed to query repository: {response.status_code} {response.text}")

def import_ttl_to_repository(repo_id, ttl_file_path):
    url = f"http://localhost:7200/repositories/{repo_id}/statements"
    headers = {"Content-Type": "text/turtle"}
    with open(ttl_file_path, "rb") as f:
        data = f.read()
    response = requests.post(url, headers=headers, data=data)
    if response.status_code in (200, 204):
        print(f"✅ Data from '{ttl_file_path}' imported into repository '{repo_id}'.")
    else:
        print(f"❌ Failed to import data: {response.status_code} {response.text}")


if __name__ == "__main__":
    repo_name = "cebm_ontology"
    ttl_output = "cebm_ontology_02.ttl"
    delete_repository(repo_name)
    create_repository_from_ttl("repo-config.ttl", repo_name)
    count_classes_in_default_ns(repo_name, "http://decide.omilab.org/cebm#")
    convert_owl_to_rdfs("cebm_ontology_02.owl", ttl_output)
    import_ttl_to_repository(repo_name, ttl_output)
    count_classes_in_default_ns(repo_name, "hhttp://decide.omilab.org/cebm#")