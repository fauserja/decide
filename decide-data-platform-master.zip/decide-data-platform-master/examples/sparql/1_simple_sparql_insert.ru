# http://localhost:7200/repositories/test_repository/statements
# Content-Type: application/sparql-update

PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

INSERT DATA {
  GRAPH <http://example.com/#graph> {
    <http://example.com/#> <rdf:type> <http://example.com/#b> .
  }
}
