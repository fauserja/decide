# DECIDE Data Platform

This project contains the artifacts required to realize the data platform for the DECIDE project.
Additionally, it contains other services necessary for the DECIDE project.



## Use locally

From inside the `.docker` directory use `docker compose --file docker-compose.yml up --detach` to create and start the containers.
Afterwards the containers can be stopped and (re-)stared using the commands `docker compose --file docker-compose.yml stop` and `docker compose --file docker-compose.yml restart` (also both from inside the `.docker` directory) respectively.

> There are also Visual Studio Code tasks defined to perform the above operations.

* Olive MSC: http://localhost:7300/micro-service-controller-rest/
* GraphDB: http://localhost:7200/
* RDF Transformation Service: http://localhost:7100/rdf-transformation-service/
* Dashboard: http://localhost:7500/

> To work with the added user groups it is necessary to get the latest (2025-07-30) Docker images for the RDF Transformation Service and Dashboard!



## Use remotely

The version from 2025-07-31 has also been deployed on a server, providing the components at the following URLs:
* Olive MSC: https://decide-prototype.omilab.org/micro-service-controller-rest/
* GraphDB: https://decide-prototype.omilab.org/
* RDF Transformation Service: https://decide-prototype.omilab.org/rdf-transformation-service/
* Dashboard: https://decide-prototype.omilab.org/dashboard/



## Notes

In GraphDB there is a repository `cebm_ontology` set up. It contains:
* Statements from `cebm_ontology_02.trig` (input from DECIDE Modelling Tool project, `.owl` file renamed to `.trig`).
* Statements from `decide_01_mm.trig` (located in `.docker/rdf-transformation-data`).
* Statements from `user-example-data-basic.trig` (example data from DECIDE Dashboard project).
* Statements from `icq-example-data.trig` (example data from DECIDE Dashboard project).
* Statements from both `agnostic-model-export-example` and `car-manufacturer-model-export-example` (example data from DECIDE Dashboard project) uploaded through the DECIDE Modelling Toolkit.

**The following has been moved to the `deprecated` folder. The up-to-date files are located in the [DECIDE Semantic Web Technology Resources]() project instead.**  
The SPARQL Update operations used by the RDF Transformation Service are deployed with the service.
The relevant folders / files are:
* `.docker/rdf-transformation-data/mm-sparql-update/` - Folder that contains `.ru` files.
  These specify the SPARQL Update operations to execute on the DECIDE meta-model description.
* `.docker/rdf-transformation-data/mm-sparql-update.xml` - XML file referencing the `.ru` files from the folder in the sequence they should be executed.
  The file paths are specified as a URL where it will be found by the server.
* `.docker/rdf-transformation-data/model-sparql-update` - Folder that contains `.ru` files.
  These specify the SPARQL Update operations to execute on the model data transformed to RDF.
* `.docker/rdf-transformation-data/model-sparql-update.xml` - XML file referencing the `.ru` files from the folder in the sequence they should be executed.
  The file paths are specified as a URL where it will be found by the server.
