{
  "properties" : {
    "current.location" : ""
  },
  "import.local" : {
    "cebm_ontology;;cebm_ontology_02.trig" : {
      "name" : "cebm_ontology_02.trig",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/cebm_ontology_02.trig",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "eedbcb74-ebde-4d5f-b56e-7c45c24e8427",
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true,
        "contextLink" : null
      },
      "size" : "14544",
      "lastModified" : 1754304363381,
      "imported" : 1754304364199,
      "addedStatements" : 197,
      "removedStatements" : 0,
      "numReplacedGraphs" : 0
    },
    "cebm_ontology;;decide_01_mm.trig" : {
      "name" : "decide_01_mm.trig",
      "status" : "DONE",
      "message" : "Imported successfully in 2s.",
      "context" : "",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/decide_01_mm.trig",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "deb81760-724c-4870-94cb-90dabfa64513",
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true,
        "contextLink" : null
      },
      "size" : "328475",
      "lastModified" : 1754304426415,
      "imported" : 1754304428958,
      "addedStatements" : 4346,
      "removedStatements" : 0,
      "numReplacedGraphs" : 0
    },
    "cebm_ontology;;user-example-data-basic.trig" : {
      "name" : "user-example-data-basic.trig",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/user-example-data-basic.trig",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "e8fe133b-5966-4ee6-90fb-f58f70aa6ff4",
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true,
        "contextLink" : null
      },
      "size" : "3334",
      "lastModified" : 1754304450522,
      "imported" : 1754304451521,
      "addedStatements" : 53,
      "removedStatements" : 0,
      "numReplacedGraphs" : 0
    },
    "cebm_ontology;;icq-example-data.trig" : {
      "name" : "icq-example-data.trig",
      "status" : "DONE",
      "message" : "Imported successfully in less than a second.",
      "context" : "",
      "replaceGraphs" : [ ],
      "baseURI" : "file:/uploaded/generated/icq-example-data.trig",
      "forceSerial" : false,
      "type" : "file",
      "format" : null,
      "data" : "e52ffac1-1c86-48da-8ea7-25ee9995bab4",
      "parserSettings" : {
        "preserveBNodeIds" : false,
        "failOnUnknownDataTypes" : false,
        "verifyDataTypeValues" : false,
        "normalizeDataTypeValues" : false,
        "failOnUnknownLanguageTags" : false,
        "verifyLanguageTags" : true,
        "normalizeLanguageTags" : false,
        "stopOnError" : true,
        "contextLink" : null
      },
      "size" : "8817",
      "lastModified" : 1754304464768,
      "imported" : 1754304465675,
      "addedStatements" : 82,
      "removedStatements" : 0,
      "numReplacedGraphs" : 0
    }
  },
  "locations" : {
    "" : {
      "location" : "",
      "authType" : "none",
      "locationType" : "GDB",
      "password" : null,
      "username" : null,
      "defaultRepository" : null
    }
  }
}