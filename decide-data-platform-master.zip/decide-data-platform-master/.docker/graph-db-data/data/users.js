{
  "users" : {
    "admin" : {
      "username" : "admin",
      "password" : "{bcrypt}$2a$10$/eSamzO1CpNAN8jh4gH/au.lbQRWg5zzonim95IwQ0Cu0biN7i2Je",
      "grantedAuthorities" : [ "ROLE_ADMIN" ],
      "appSettings" : {
        "DEFAULT_INFERENCE" : true,
        "DEFAULT_VIS_GRAPH_SCHEMA" : true,
        "DEFAULT_SAMEAS" : true,
        "IGNORE_SHARED_QUERIES" : false,
        "EXECUTE_COUNT" : true,
        "COOKIE_CONSENT" : {
          "policyAccepted" : true,
          "statistic" : true,
          "thirdParty" : true,
          "updatedAt" : 1751379266595
        }
      },
      "dateCreated" : 1751365110692,
      "gptThreads" : [ ]
    }
  },
  "user_queries" : {
    "admin" : {
      "SPARQL Select template" : {
        "name" : "SPARQL Select template",
        "body" : "SELECT ?s ?p ?o\nWHERE {\n\t?s ?p ?o .\n} LIMIT 100",
        "shared" : false
      },
      "Clear graph" : {
        "name" : "Clear graph",
        "body" : "CLEAR GRAPH <http://example>",
        "shared" : false
      },
      "Add statements" : {
        "name" : "Add statements",
        "body" : "PREFIX dc: <http://purl.org/dc/elements/1.1/>\nINSERT DATA\n      {\n      GRAPH <http://example> {\n          <http://example/book1> dc:title \"A new book\" ;\n                                 dc:creator \"A.N.Other\" .\n          }\n      }",
        "shared" : false
      },
      "Remove statements" : {
        "name" : "Remove statements",
        "body" : "PREFIX dc: <http://purl.org/dc/elements/1.1/>\nDELETE DATA\n{\nGRAPH <http://example> {\n    <http://example/book1> dc:title \"A new book\" ;\n                           dc:creator \"A.N.Other\" .\n    }\n}",
        "shared" : false
      },
      "DEL things" : {
        "name" : "DEL things",
        "body" : "PREFIX adoxx_mm: <https://www.adoxx.org/mm#>\nPREFIX cebm:     <http://example.org/cebm#>\nPREFIX cebmauth: <http://example.org/cebm/auth/#>\nPREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>\nPREFIX owl:      <http://www.w3.org/2002/07/owl#>\nPREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nPREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>\nPREFIX xml:      <http://www.w3.org/XML/1998/namespace>\nPREFIX xsd:      <http://www.w3.org/2001/XMLSchema#>\n\nDELETE {\n    ?s ?p ?o .\n}\nWHERE {\n    ?s ?p ?o .\n    FILTER(\n        STRSTARTS(STR(?s), STR(mm:)) ||\n        STRSTARTS(STR(?s), STR(cebm:)) ||\n        STRSTARTS(STR(?s), STR(cv:))\n    )\n}\n",
        "shared" : false
      },
      "Clear repository" : {
        "name" : "Clear repository",
        "body" : "PREFIX adoxx_mm: <https://www.adoxx.org/mm#>\nPREFIX cebm:     <http://example.org/cebm#>\nPREFIX cebmauth: <http://example.org/cebm/auth/#>\nPREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>\nPREFIX owl:      <http://www.w3.org/2002/07/owl#>\nPREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nPREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>\nPREFIX xml:      <http://www.w3.org/XML/1998/namespace>\nPREFIX xsd:      <http://www.w3.org/2001/XMLSchema#>\n\n# Delete all graphs (GraphDB basic triples and CEBM ontology are outside of graphs).\nDELETE {\n    GRAPH ?g {\n        ?s ?p ?o .\n    }\n}\nWHERE {\n    GRAPH ?g {\n    \t?s ?p ?o .\n    }\n} ;\n\n# Delete all triples where the subject is not in one of the default namespaces (owl, rdf, rdfs, xsd).\nDELETE {\n    ?s ?p ?o .\n}\nWHERE {\n    ?s ?p ?o .\n    FILTER(\n        !STRSTARTS(STR(?s), STR(owl:)) &&\n        !STRSTARTS(STR(?s), STR(rdf:)) &&\n        !STRSTARTS(STR(?s), STR(rdfs:)) &&\n        !STRSTARTS(STR(?s), STR(xsd:))\n    )\n} ;\n\n# Delete all triples where the property is not in one of the default namespaces (owl, rdf, rdfs, xsd).\nDELETE {\n    ?s ?p ?o .\n}\nWHERE {\n    ?s ?p ?o .\n    FILTER(\n        !STRSTARTS(STR(?p), STR(owl:)) &&\n        !STRSTARTS(STR(?p), STR(rdf:)) &&\n        !STRSTARTS(STR(?p), STR(rdfs:)) &&\n        !STRSTARTS(STR(?p), STR(xsd:))\n    )\n} ;\n\n# Delete all triples where the object is not in one of the default namespaces (owl, rdf, rdfs, xsd).\nDELETE {\n    ?s ?p ?o .\n}\nWHERE {\n    ?s ?p ?o .\n    FILTER(\n        !STRSTARTS(STR(?o), STR(owl:)) &&\n        !STRSTARTS(STR(?o), STR(rdf:)) &&\n        !STRSTARTS(STR(?o), STR(rdfs:)) &&\n        !STRSTARTS(STR(?o), STR(xsd:))\n    )\n}\n",
        "shared" : false
      },
      "All subjects" : {
        "name" : "All subjects",
        "body" : "PREFIX adoxx_mm: <https://www.adoxx.org/mm#>\nPREFIX cebm:     <http://example.org/cebm#>\nPREFIX cebmauth: <http://example.org/cebm/auth/#>\nPREFIX mm:       <http://example.org/cebm/adoxx-rdf/#>\nPREFIX owl:      <http://www.w3.org/2002/07/owl#>\nPREFIX rdf:      <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nPREFIX rdfs:     <http://www.w3.org/2000/01/rdf-schema#>\nPREFIX xml:      <http://www.w3.org/XML/1998/namespace>\nPREFIX xsd:      <http://www.w3.org/2001/XMLSchema#>\n\nSELECT DISTINCT ?s\nWHERE {\n    ?s rdf:type owl:Class .\n    # Use to only include specific namespaces.\n    #FILTER(STRSTARTS(STR(?s), STR(cebm:)))\n    # Use to exclude sepcific namespaces.\n    FILTER (\n        !STRSTARTS(STR(?s), STR(owl:)) &&\n        !STRSTARTS(STR(?s), STR(rdf:)) &&\n        !STRSTARTS(STR(?s), STR(rdfs:)) &&\n        !STRSTARTS(STR(?s), STR(xsd:))\n\t)\n}\n",
        "shared" : false
      }
    }
  }
}